"""Comprehensive test suite for website content extraction, failure diagnosis, and boundaries."""

import socket
import pytest

from artifacts.safelytics import app as app_module
from artifacts.safelytics.analysis import (
    classify_content,
    extract_text,
    inspect_html_content,
)
from artifacts.safelytics.browser import (
    is_browser_fallback_available,
    is_browser_fallback_enabled,
    render_javascript_page,
)
from artifacts.safelytics.security import (
    FetchFailure,
    UnsafeTarget,
    decode_html_bytes,
    fetch_page,
    normalize_url,
)
from artifacts.safelytics.storage import list_scans


class MockResponse:
    """Configurable mock response for requests."""

    def __init__(
        self,
        status_code=200,
        body=b"<html><body><h1>Title</h1><p>Sample readable body text for safety analysis.</p></body></html>",
        headers=None,
    ):
        self.status_code = status_code
        self.headers = headers if headers is not None else {"Content-Type": "text/html; charset=utf-8"}
        self._body = body
        self.closed = False

    def raise_for_status(self):
        if self.status_code >= 400:
            import requests

            raise requests.HTTPError(response=self)

    def iter_content(self, chunk_size=16384):
        offset = 0
        while offset < len(self._body):
            yield self._body[offset : offset + chunk_size]
            offset += chunk_size

    def close(self):
        self.closed = True


class MockSession:
    """Mock session with queued responses."""

    def __init__(self, responses):
        self.trust_env = True
        self.responses = list(responses)
        self.calls = []
        self.closed = False

    def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        if not self.responses:
            raise RuntimeError("No more mock responses queued.")
        return self.responses.pop(0)

    def close(self):
        self.closed = True


def mock_public_resolver(host, port, type=socket.SOCK_STREAM):
    return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", port))]


# ── 1. Normal HTML Extraction & Metadata ──


def test_normal_html_extraction_with_headings_paragraphs_and_metadata():
    html = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Children's Space Exploration Club</title>
        <meta name="description" content="An educational site for kids about planets, stars, and rockets." />
        <meta name="keywords" content="astronomy, kids, education, space" />
    </head>
    <body>
        <main>
            <h1>Explore the Solar System</h1>
            <p>Welcome to our astronomy club. Learn about Mars, Jupiter, and Saturn.</p>
            <article>
                <h2>Telescope Tips</h2>
                <p>Never look directly at the sun with any optical instrument.</p>
                <ul>
                    <li>Start with binoculars.</li>
                    <li>Find a dark location away from streetlights.</li>
                </ul>
            </article>
        </main>
    </body>
    </html>
    """
    inspection = inspect_html_content(html)
    assert inspection["available"] is True
    assert inspection["status"] == "success"
    assert "children's space exploration club" in inspection["title"].lower()
    assert "educational site for kids" in inspection["meta_description"].lower()
    assert "explore the solar system" in inspection["text"]
    assert "telescope tips" in inspection["text"]
    assert "never look directly at the sun" in inspection["text"]
    assert "start with binoculars" in inspection["text"]


# ── 2. Malformed HTML Parsing ──


def test_malformed_html_parsing_graceful():
    malformed = """
    <!DOCTYPE html>
    <html>
    <head><title>Unclosed Tags Guide</title>
    <body>
        <h1>Malformed Page
        <p>This paragraph tag is not closed properly.
        <table border=1>
            <tr><td>Cell 1<td>Cell 2 without closing tr
        </table>
        <div>Broken nesting <b>bold text <i>italic</b></i> outside</div>
        <p>Final trailing text after broken markup.
    """
    inspection = inspect_html_content(malformed)
    assert inspection["available"] is True
    assert "unclosed tags guide" in inspection["title"].lower()
    assert "malformed page" in inspection["text"]
    assert "this paragraph tag is not closed" in inspection["text"]
    assert "cell 1" in inspection["text"]
    assert "cell 2" in inspection["text"]
    assert "final trailing text after broken markup" in inspection["text"]


# ── 3. Content Inside Forms Preserved (ASP.NET Support) ──


def test_content_inside_form_preserved_for_aspnet():
    aspnet_html = """
    <html>
    <head><title>Student Information Portal</title></head>
    <body>
        <form name="aspnetForm" method="post" action="./default.aspx" id="aspnetForm">
            <h1>School District Announcements</h1>
            <p>Summer reading lists are now available for all middle school students.</p>
            <p>Please review the safety guidelines with your parents.</p>
            <input type="hidden" name="__VIEWSTATE" value="xyz123" />
            <input type="submit" name="btnSubmit" value="Submit" />
        </form>
    </body>
    </html>
    """
    text = extract_text(aspnet_html)
    assert "student information portal" in text
    assert "school district announcements" in text
    assert "summer reading lists are now available" in text
    assert "review the safety guidelines" in text


# ── 4. Clutter & Hidden Elements Removal ──


def test_clutter_and_hidden_elements_removal():
    html = """
    <html>
    <head><title>Clean Content Test</title><style>.banner{color:blue} .hide{display:none}</style></head>
    <body>
        <nav><a>Home</a><a>About</a><a>Contact</a></nav>
        <header>Header Clutter</header>
        <main>
            <h1>Main Article Heading</h1>
            <p>Substantive article text that must be preserved and indexed.</p>
            <div hidden>Sensitive hidden data</div>
            <div style="display: none">Inline CSS hidden data</div>
            <div style="visibility:hidden">Visibility hidden text</div>
            <span aria-hidden="true">Screen-reader hidden icon</span>
        </main>
        <aside>Related sponsor links</aside>
        <footer>Copyright 2026. All rights reserved.</footer>
        <script>console.log("secret script execution");</script>
        <noscript>Javascript disabled fallback</noscript>
    </body>
    </html>
    """
    text = extract_text(html)
    assert "clean content test" in text
    assert "main article heading" in text
    assert "substantive article text" in text

    # Verify clutter is stripped
    for clutter in (
        "sensitive hidden data",
        "inline css hidden data",
        "visibility hidden text",
        "screen-reader hidden icon",
        "secret script execution",
        "copyright 2026",
    ):
        assert clutter not in text


# ── 5. Character Encoding Handling & Mojibake Prevention ──


def test_encoding_utf8_bom():
    raw = b"\xef\xbb\xbf<html><head><title>BOM Test</title></head><body><p>Hello world with UTF-8 BOM</p></body></html>"
    text, enc = decode_html_bytes(raw, "text/html")
    assert enc == "utf-8-sig"
    assert "Hello world with UTF-8 BOM" in text


def test_encoding_mojibake_prevention_when_server_sends_latin1_default():
    """Server sends Content-Type: text/html; charset=ISO-8859-1, but the page is actually UTF-8."""
    # "Café & Naïve" in UTF-8
    utf8_body = "<html><head><title>Café & Naïve</title></head><body><p>Welcome to our café.</p></body></html>".encode(
        "utf-8"
    )
    text, enc = decode_html_bytes(utf8_body, "text/html; charset=ISO-8859-1")
    assert enc == "utf-8"
    assert "Café" in text
    assert "café" in text
    assert "CafÃ©" not in text  # No Mojibake!


def test_encoding_cp1252_when_actually_cp1252():
    """Server sends Windows-1252 and body has Windows-1252 bytes."""
    cp1252_body = "<html><head><meta charset='windows-1252'></head><body><p>Café au lait</p></body></html>".encode(
        "cp1252"
    )
    text, enc = decode_html_bytes(cp1252_body, "text/html; charset=windows-1252")
    assert "windows-1252" in enc.lower() or "cp1252" in enc.lower()
    assert "Café au lait" in text


# ── 6. Empty and Whitespace Responses ──


def test_empty_and_whitespace_responses_raise_fetch_failure(monkeypatch):
    import artifacts.safelytics.security as sec

    for empty_body in (b"", b"   \r\n\t  "):
        session = MockSession([MockResponse(200, body=empty_body)])
        monkeypatch.setattr(sec.requests, "Session", lambda: session)
        with pytest.raises(FetchFailure) as exc:
            fetch_page("https://example.com/", resolver=mock_public_resolver)
        assert exc.value.failure_type == "empty_response"
        assert "empty response" in str(exc.value).lower()


# ── 7. Unsupported Content Types ──


def test_unsupported_content_types(monkeypatch):
    import artifacts.safelytics.security as sec

    # Case A: PDF declared in Content-Type
    session = MockSession(
        [
            MockResponse(
                200,
                body=b"%PDF-1.5 document data",
                headers={"Content-Type": "application/pdf"},
            )
        ]
    )
    monkeypatch.setattr(sec.requests, "Session", lambda: session)
    with pytest.raises(FetchFailure) as exc:
        fetch_page("https://example.com/doc.pdf", resolver=mock_public_resolver)
    assert exc.value.failure_type == "unsupported_type"
    assert "not an html page" in str(exc.value).lower()

    # Case B: Missing Content-Type with binary PDF magic bytes
    session2 = MockSession(
        [MockResponse(200, body=b"%PDF-1.5 binary stream", headers={})]
    )
    monkeypatch.setattr(sec.requests, "Session", lambda: session2)
    with pytest.raises(FetchFailure) as exc2:
        fetch_page("https://example.com/file", resolver=mock_public_resolver)
    assert exc2.value.failure_type == "unsupported_type"


# ── 8. HTTP Errors and Challenge Detection ──


def test_http_error_handling_and_challenges(monkeypatch):
    import artifacts.safelytics.security as sec

    # 403 Standard Bot Block
    session_403 = MockSession(
        [MockResponse(403, body=b"Forbidden", headers={"Content-Type": "text/html"})]
    )
    monkeypatch.setattr(sec.requests, "Session", lambda: session_403)
    with pytest.raises(FetchFailure) as exc_403:
        fetch_page("https://example.com/", resolver=mock_public_resolver)
    assert exc_403.value.failure_type == "blocked"
    assert exc_403.value.status_code == 403

    # 403 Cloudflare Turnstile / Challenge
    cf_body = b"<html><head><title>Just a moment...</title></head><body><h1>Checking your browser</h1><p>cf-chl-widget</p></body></html>"
    session_cf = MockSession(
        [MockResponse(403, body=cf_body, headers={"Content-Type": "text/html"})]
    )
    monkeypatch.setattr(sec.requests, "Session", lambda: session_cf)
    with pytest.raises(FetchFailure) as exc_cf:
        fetch_page("https://example.com/", resolver=mock_public_resolver)
    assert exc_cf.value.failure_type == "challenge"
    assert "will not bypass" in str(exc_cf.value).lower()

    # 429 Rate Limit
    session_429 = MockSession(
        [MockResponse(429, body=b"Too Many Requests", headers={"Content-Type": "text/html"})]
    )
    monkeypatch.setattr(sec.requests, "Session", lambda: session_429)
    with pytest.raises(FetchFailure) as exc_429:
        fetch_page("https://example.com/", resolver=mock_public_resolver)
    assert exc_429.value.failure_type == "rate_limited"
    assert exc_429.value.status_code == 429


# ── 9. JavaScript-Rendered Pages Detection ──


def test_javascript_dependent_spa_detection():
    # React SPA with boilerplate message
    react_html = """
    <!DOCTYPE html>
    <html>
    <head><title>React App</title><script src="/bundle.js"></script></head>
    <body>
        <noscript>You need to enable JavaScript to run this app.</noscript>
        <div id="root"></div>
    </body>
    </html>
    """
    inspection = inspect_html_content(react_html)
    assert inspection["available"] is False
    assert inspection["status"] == "javascript_required"
    assert "client-side javascript" in inspection["notice"].lower()
    assert len(inspection["uncompleted_checks"]) > 0

    # Page displaying only "Please enable JavaScript" text
    js_text_page = """
    <html><head><title>Portal</title></head><body>
    <h1>JavaScript Required</h1>
    <p>Please enable JavaScript in your browser to view this site.</p>
    </body></html>
    """
    inspection_text = inspect_html_content(js_text_page)
    assert inspection_text["available"] is False
    assert inspection_text["status"] == "javascript_required"


# ── 10. Oversized Response Truncation (2 MiB Limit) ──


def test_oversized_response_truncation(monkeypatch):
    import artifacts.safelytics.security as sec

    # Create a 2.5 MiB HTML body
    header_part = b"<html><head><title>Large Encyclopedia</title></head><body><h1>Big Article</h1><p>"
    repeat_text = b"This is safe informational text about nature and animals. " * 50_000
    footer_part = b"</p></body></html>"
    huge_body = header_part + repeat_text + footer_part
    assert len(huge_body) > 2 * 1024 * 1024

    session = MockSession(
        [
            MockResponse(
                200,
                body=huge_body,
                headers={"Content-Type": "text/html; charset=utf-8"},
            )
        ]
    )
    monkeypatch.setattr(sec.requests, "Session", lambda: session)

    # Should NOT raise FetchFailure; should truncate gracefully
    fetched = fetch_page("https://example.com/huge", resolver=mock_public_resolver)
    assert fetched["is_truncated"] is True
    assert fetched["fetch_status"] == "partial"
    assert "exceeded the 2 mib limit" in fetched["notice"].lower()
    assert "Large Encyclopedia" in fetched["html"]


# ── 11. Unreadable Pages Never Marked Safe (Requirement 5) ──


def test_unreadable_pages_never_marked_safe(tmp_path, monkeypatch):
    """Ensure that when content cannot be read, the risk level is Unknown, not Low Risk."""
    db = str(tmp_path / "safety_boundary.sqlite3")
    client = app_module.create_app({"TESTING": True, "DATABASE": db}).test_client()

    # Mock an inaccessible 403 page
    monkeypatch.setattr(
        app_module,
        "fetch_page",
        lambda url: (_ for _ in ()).throw(
            FetchFailure(
                "This website blocks automated requests (403 Forbidden).",
                failure_type="blocked",
                status_code=403,
            )
        ),
    )

    res = client.post("/analyze", data={"url": "https://blocked-site.example/"})
    assert res.status_code == 200
    assert b"Overall Website Risk" in res.data
    # Risk must be Unknown with grey color, NEVER Low Risk / Safe
    assert b"Unknown" in res.data
    assert b"banner-grey" in res.data
    assert b"Low Risk" not in res.data
    assert b"Uncompleted Checks" in res.data


# ── 12. Optional Browser Fallback Boundary (Requirement 3 & 4) ──


def test_browser_fallback_disabled_by_default(monkeypatch):
    """Verify browser fallback is disabled by default and handles invocation safely."""
    monkeypatch.delenv("SAFELYTICS_ENABLE_BROWSER", raising=False)
    assert is_browser_fallback_enabled() is False
    assert is_browser_fallback_available() is False

    result = render_javascript_page("https://example.com/")
    assert result["success"] is False
    assert "disabled by default" in result["error"].lower()


def test_browser_fallback_rejects_ssrf_when_enabled(monkeypatch):
    """Verify that even when browser fallback is enabled, private IP targets are blocked."""
    monkeypatch.setenv("SAFELYTICS_ENABLE_BROWSER", "1")

    # Target points to localhost
    result = render_javascript_page("http://127.0.0.1/admin")
    assert result["success"] is False
    assert "security check rejected" in result["error"].lower()
