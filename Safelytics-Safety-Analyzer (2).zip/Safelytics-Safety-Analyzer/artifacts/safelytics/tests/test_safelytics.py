import json
import socket

import pytest

from artifacts.safelytics import app as app_module
from artifacts.safelytics.analysis import (
    analyze_domain,
    analyze_phishing,
    annotate_finding_contributions,
    calculate_risk,
    classify_content,
    compare_scans,
    extract_text,
    inspect_html_content,
    score_findings,
)
from artifacts.safelytics.evaluation import compute_metrics, evaluate_dataset
from artifacts.safelytics.security import (
    FetchFailure,
    UnsafeTarget,
    fetch_page,
    normalize_url,
    resolve_public_addresses,
)
from artifacts.safelytics.storage import get_scan, list_scans, save_scan


def test_normalize_url_accepts_bare_domain_and_removes_fragment():
    assert normalize_url(" Example.COM/path#section ") == "https://example.com/path"
    assert normalize_url("http://example.com") == "http://example.com/"


@pytest.mark.parametrize(
    "url",
    [
        "file:///etc/passwd",
        "ftp://example.com",
        "http://localhost",
        "http://machine.local/",
        "https://user:password@example.com/",
        "https://example.com:8443/",
        "https://example.com/a b",
    ],
)
def test_normalize_url_rejects_disallowed_targets(url):
    with pytest.raises(UnsafeTarget):
        normalize_url(url)


def test_dns_validation_rejects_private_and_mixed_answers():
    def private_resolver(host, port, type):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", port))]

    with pytest.raises(UnsafeTarget, match="private or reserved"):
        resolve_public_addresses("public-looking.example", 443, resolver=private_resolver)


def test_content_findings_do_not_become_phishing_findings():
    content = classify_content("This fictional page discusses adult content in an educational context.")
    phishing = analyze_phishing(
        "https://school.example/",
        "This fictional page discusses adult content in an educational context.",
    )

    assert content["adult_count"] > 0
    assert content["risk_score"] == 10.0
    assert phishing["findings"] == []


def test_phishing_rules_explain_lookalike_and_sensitive_route():
    report = analyze_phishing(
        "https://signin.paypa1.example/secure/account/verify",
        "<html><body>Please verify your account now.</body></html>",
    )
    ids = {finding["id"] for finding in report["findings"]}

    assert "url.brand_impersonation" in ids
    assert "url.sensitive_route" in ids
    assert "text.urgent_account_language" in ids
    assert report["risk_score"] <= 10


def test_scoring_deduplicates_rule_ids_and_explains_missing_components():
    one_finding = {
        "id": "same-rule",
        "weight": 2.5,
    }
    assert score_findings([one_finding, one_finding]) == 2.5

    risk = calculate_risk(
        {"risk_score": None},
        {"risk_score": 4.0},
        {"risk_score": 2.0},
        {"privacy_score": None},
    )
    assert risk["score_breakdown"][0]["score"] is None
    assert risk["score_breakdown"][3]["score"] is None
    assert risk["risk_score"] == 3.2


def test_each_finding_shows_component_and_weighted_score_contribution():
    findings = [
        {"category": "phishing_scam", "weight": 2.0},
        {"category": "domain_redirect", "weight": 1.0},
        {"category": "child_content", "weight": None},
    ]
    breakdown = [
        {"component": "phishing_scam", "weight": 0.3},
        {"component": "domain_redirect", "weight": 0.2},
        {"component": "privacy", "weight": 0.5},
    ]

    annotated = annotate_finding_contributions(findings, breakdown)
    assert annotated[0]["score_contribution"] == 2.0
    assert annotated[0]["overall_contribution"] == 0.6
    assert annotated[1]["overall_contribution"] == 0.2
    assert annotated[2]["overall_contribution"] is None


class FakeResponse:
    def __init__(self, status_code, body=b"<html><body>Example</body></html>", headers=None):
        self.status_code = status_code
        self.headers = headers or {"Content-Type": "text/html; charset=utf-8"}
        self.encoding = "utf-8"
        self._body = body
        self.closed = False

    def raise_for_status(self):
        if self.status_code >= 400:
            import requests

            raise requests.HTTPError(response=self)

    def iter_content(self, chunk_size):
        yield self._body

    def close(self):
        self.closed = True


class FakeSession:
    def __init__(self, responses):
        self.trust_env = True
        self.responses = list(responses)
        self.calls = []
        self.closed = False

    def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return self.responses.pop(0)

    def close(self):
        self.closed = True


def public_resolver(host, port, type=socket.SOCK_STREAM):
    return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", port))]


def test_redirects_are_manual_recorded_and_checked(monkeypatch):
    import artifacts.safelytics.security as security

    session = FakeSession(
        [
            FakeResponse(302, headers={"Location": "https://www.example.com/final"}),
            FakeResponse(200),
        ]
    )
    monkeypatch.setattr(security.requests, "Session", lambda: session)
    result = fetch_page("https://example.com/", resolver=public_resolver)

    assert len(session.calls) == 2
    assert all(call[1]["allow_redirects"] is False for call in session.calls)
    assert result["final_url"] == "https://www.example.com/final"
    assert result["redirect_chain"][0]["status_code"] == 302
    assert result["redirect_chain"][0]["followed"] is True
    assert session.closed


def test_redirect_to_private_address_is_blocked_before_following(monkeypatch):
    import artifacts.safelytics.security as security

    session = FakeSession(
        [FakeResponse(302, headers={"Location": "http://127.0.0.1/admin"})]
    )
    monkeypatch.setattr(security.requests, "Session", lambda: session)

    with pytest.raises(FetchFailure) as failure:
        fetch_page("https://example.com/", resolver=public_resolver)
    assert len(session.calls) == 1
    assert failure.value.final_url == "https://example.com/"
    assert failure.value.redirect_chain[0]["blocked"] is True
    assert failure.value.redirect_chain[0]["followed"] is False


def sample_scan(url, scanned_at, risk_score=1.0):
    return {
        "url": url,
        "normalized_url": url,
        "risk_score": risk_score,
        "risk_level": "Low Risk",
        "risk_color": "green",
        "component_scores": {
            "child_content": 0.0,
            "phishing_scam": 0.0,
            "domain_redirect": 0.0,
            "privacy": 0.0,
        },
        "limitations": ["Static HTML only"],
        "findings": [],
        "scanned_at": scanned_at,
        "content": {
            "categories": {
                "Adult Content": {"count": 0},
                "Violence": {"count": 0},
                "Hate Speech": {"count": 0},
                "Gambling": {"count": 0},
            }
        },
        "domain": {
            "final_url": url,
            "redirect_chain": [],
        },
        "privacy": {
            "tracker_domains": [],
            "third_party_resources": [],
            "external_form_destinations": [],
            "cookie_indicators": [],
            "privacy_policy_links": [],
        },
    }


def test_history_storage_redacts_sensitive_query_values_and_round_trips(tmp_path):
    database = tmp_path / "history.sqlite3"
    from artifacts.safelytics.storage import initialize_database

    initialize_database(database)
    scan = sample_scan(
        "https://example.com/?token=do-not-save&apiKey=another-secret&view=kids",
        "2026-10-09T10:00:00+00:00",
    )
    scan_id = save_scan(scan, database)

    saved = get_scan(scan_id, database)
    assert "do-not-save" not in json.dumps(saved)
    assert "another-secret" not in json.dumps(saved)
    assert "token=%5Bredacted%5D" in saved["url"]
    assert len(list_scans(path=database)) == 1


def test_compare_scans_reports_content_redirect_privacy_and_score_changes():
    first = sample_scan("https://example.com/", "2026-01-01T00:00:00+00:00")
    second = sample_scan("https://example.com/", "2026-02-01T00:00:00+00:00", 3.0)
    second["component_scores"]["privacy"] = 4.0
    second["content"]["categories"]["Adult Content"]["count"] = 1
    second["domain"]["final_url"] = "https://different.example/"
    second["privacy"]["tracker_domains"] = ["analytics.example"]

    comparison = compare_scans(first, second)
    changed = {row["label"] for row in comparison["changes"] if row["changed"]}
    assert "Overall risk score" in changed
    assert "Privacy score" in changed
    assert "Content category counts" in changed
    assert "Final destination" in changed
    assert "Known tracker domains" in changed
    assert "does not by itself prove" in comparison["notice"]


def test_compare_rejects_different_sites():
    with pytest.raises(ValueError, match="same normalized website"):
        compare_scans(
            sample_scan("https://one.example/", "2026-01-01"),
            sample_scan("https://two.example/", "2026-01-02"),
        )


def test_incomplete_scans_show_unavailable_data_instead_of_empty_findings():
    earlier = sample_scan("https://example.com/", "2026-01-01T00:00:00+00:00")
    earlier["content"] = {"available": False}
    earlier["component_scores"]["child_content"] = None
    earlier["privacy"]["available"] = False
    earlier["component_scores"]["privacy"] = None
    earlier["domain"].update(
        {
            "final_url": None,
            "final_url_available": False,
            "redirect_chain": None,
            "redirect_analysis_available": False,
        }
    )
    later = sample_scan("https://example.com/", "2026-02-01T00:00:00+00:00")

    comparison = compare_scans(earlier, later)
    rows = {row["label"]: row for row in comparison["changes"]}
    assert rows["Content category counts"]["before"] is None
    assert rows["Known tracker domains"]["before"] is None
    assert rows["Final destination"]["before"] is None
    assert rows["Redirect destinations"]["before"] is None


def test_metrics_and_synthetic_dataset_evaluation():
    metrics = compute_metrics(
        ["suspicious", "legitimate", "suspicious", "legitimate"],
        ["suspicious", "suspicious", "legitimate", "legitimate"],
    )
    assert metrics["precision"] == 0.5
    assert metrics["recall"] == 0.5
    assert metrics["false_positive_rate"] == 0.5
    assert metrics["false_negative_rate"] == 0.5

    evaluated = evaluate_dataset()
    assert evaluated["metrics"]["examples"] == 6
    assert "Synthetic examples only" in evaluated["metrics"]["dataset_note"]


def test_homepage_learning_quiz_scan_history_and_comparison_flow(tmp_path, monkeypatch):
    client = app_module.create_app(
        {"TESTING": True, "DATABASE": str(tmp_path / "web-history.sqlite3")}
    ).test_client()

    assert client.get("/").status_code == 200
    assert client.get("/history").status_code == 200
    assert client.get("/learn").status_code == 200
    quiz = client.post(
        "/learn",
        data={"question_id": "https", "answer": "encrypted"},
    )
    assert b"Correct. HTTPS" in quiz.data

    page = (
        "<html><body><h1>Community page</h1>"
        "<p>This is a sample website with enough descriptive text for an overview.</p>"
        "<a href='/privacy'>Privacy policy</a></body></html>"
    )
    monkeypatch.setattr(
        app_module,
        "fetch_page",
        lambda url: {
            "html": page,
            "final_url": url,
            "redirect_chain": [],
            "notice": None,
        },
    )
    result_one = client.post("/analyze", data={"url": "https://library.example/"})
    result_two = client.post("/analyze", data={"url": "https://library.example/"})
    assert result_one.status_code == 200
    assert b"Risk Score Breakdown" in result_one.data
    assert result_two.status_code == 200

    history = client.get("/history")
    assert b"Recent scans" in history.data
    scans = app_module.storage.list_scans(path=tmp_path / "web-history.sqlite3")
    compared = client.get(
        f"/compare?scan_a={scans[1]['id']}&scan_b={scans[0]['id']}"
    )
    assert compared.status_code == 200
    assert b"Changed scan results show different observations" in compared.data


def test_invalid_url_is_rejected_without_fetching(tmp_path, monkeypatch):
    client = app_module.create_app(
        {"TESTING": True, "DATABASE": str(tmp_path / "invalid.sqlite3")}
    ).test_client()
    monkeypatch.setattr(
        app_module,
        "fetch_page",
        fetch_page,
    )
    response = client.post("/analyze", data={"url": "http://192.168.1.1/"})
    assert response.status_code == 400
    assert b"private or reserved" in response.data


def test_blocked_redirect_remains_visible_in_partial_scan_history(tmp_path, monkeypatch):
    import artifacts.safelytics.security as security

    session = FakeSession(
        [FakeResponse(302, headers={"Location": "http://127.0.0.1/admin"})]
    )
    monkeypatch.setattr(security.requests, "Session", lambda: session)
    monkeypatch.setattr(
        app_module,
        "fetch_page",
        lambda url: security.fetch_page(url, resolver=public_resolver),
    )
    database = tmp_path / "blocked-redirect.sqlite3"
    client = app_module.create_app(
        {"TESTING": True, "DATABASE": str(database)}
    ).test_client()

    response = client.post("/analyze", data={"url": "https://example.com/"})
    assert response.status_code == 200
    assert b"Blocked" in response.data
    assert b"Redirect destination was not followed" in response.data

    saved = list_scans(path=database)[0]
    assert saved["domain"]["redirect_chain"][0]["blocked"] is True
    assert saved["domain"]["final_url"] == "https://example.com/"


def test_compare_normalizes_same_site_and_tracks_phishing_evidence_changes():
    earlier = sample_scan("https://EXAMPLE.com", "2026-01-01T00:00:00+00:00")
    later = sample_scan("https://example.com/", "2026-02-01T00:00:00+00:00")
    earlier["normalized_url"] = "https://EXAMPLE.com"
    later["normalized_url"] = ""
    earlier["phishing"] = {
        "findings": [{"title": "Look-alike link", "evidence": "old.example"}]
    }
    later["phishing"] = {
        "findings": [{"title": "Look-alike link", "evidence": "new.example"}]
    }

    comparison = compare_scans(earlier, later)
    phishing = next(
        row for row in comparison["changes"] if row["label"] == "Phishing findings"
    )
    assert phishing["comparable"] is True
    assert phishing["changed"] is True


def test_compare_rejects_different_paths_and_missing_addresses():
    with pytest.raises(ValueError, match="same normalized website"):
        compare_scans(
            sample_scan("https://example.com/one", "2026-01-01"),
            sample_scan("https://example.com/two", "2026-01-02"),
        )

    missing = sample_scan("", "2026-01-01")
    missing["normalized_url"] = ""
    with pytest.raises(ValueError, match="valid website address"):
        compare_scans(missing, sample_scan("https://example.com/", "2026-01-02"))


def test_incomplete_compare_values_are_not_reported_as_unchanged():
    earlier = sample_scan("https://example.com/", "2026-01-01")
    later = sample_scan("https://example.com/", "2026-01-02")
    earlier["content"] = {"available": False}
    earlier["component_scores"] = None
    comparison = compare_scans(earlier, later)
    content = next(
        row
        for row in comparison["changes"]
        if row["label"] == "Content category counts"
    )
    assert content["before"] is None
    assert content["comparable"] is False
    assert content["changed"] is False
    component = next(
        row for row in comparison["changes"] if row["label"] == "Child Content score"
    )
    assert component["before"] is None
    assert component["comparable"] is False


def test_compare_route_retains_selection_and_explains_invalid_scan_choices(tmp_path):
    database = tmp_path / "compare-errors.sqlite3"
    client = app_module.create_app(
        {"TESTING": True, "DATABASE": str(database)}
    ).test_client()
    first_id = save_scan(
        sample_scan("https://example.com/", "2026-01-01T00:00:00+00:00"),
        database,
    )
    second_id = save_scan(
        sample_scan("https://example.com/", "2026-02-01T00:00:00+00:00"),
        database,
    )

    response = client.get(f"/compare?scan_a={first_id}&scan_b={second_id}")
    assert response.status_code == 200
    assert f'<option value="{first_id}" selected>'.encode() in response.data
    assert f'<option value="{second_id}" selected>'.encode() in response.data

    same_scan = client.get(f"/compare?scan_a={first_id}&scan_b={first_id}")
    assert b"Choose two different saved scans" in same_scan.data
    invalid_id = client.get("/compare?scan_a=not-a-number&scan_b=999")
    assert b"Choose two valid scans" in invalid_id.data
    missing_scan = client.get(f"/compare?scan_a={first_id}&scan_b=999999")
    assert b"no longer available" in missing_scan.data


def test_learning_page_has_india_help_resources_and_new_quiz_feedback(tmp_path):
    client = app_module.create_app(
        {"TESTING": True, "DATABASE": str(tmp_path / "learning.sqlite3")}
    ).test_client()
    page = client.get("/learn")
    assert page.status_code == 200
    assert b"Phishing and tricky links" in page.data
    assert b"1930" in page.data and b"tel:1930" in page.data
    assert b"1098" in page.data and b"tel:1098" in page.data
    assert b"112" in page.data and b"tel:112" in page.data
    assert b"https://www.cybercrime.gov.in/" in page.data
    assert b"https://wcd.gov.in/child/child-helpline" in page.data
    assert b"https://112.gov.in/" in page.data
    assert b"never forward intimate or abusive images" in page.data.lower()

    answer = client.post(
        "/learn",
        data={"question_id": "financial-fraud", "answer": "bank"},
    )
    assert b"call 1930" in answer.data.lower()
    wrong_answer = client.post(
        "/learn",
        data={"question_id": "ask-help", "answer": "pay"},
    )
    assert b"Do not pay or confront them" in wrong_answer.data


def test_html_extraction_keeps_visible_content_and_marks_unreadable_pages():
    html = """
    <html><head><title>Family safety guide</title><style>.secret {display:none}</style></head>
    <body><nav>Navigation noise</nav><main><h1>Play with care</h1>
    <p>Ask a trusted adult before sharing private information with strangers online.</p>
    <ul><li>Use a unique password for important accounts.</li></ul></main>
    <div hidden>Hidden content</div><div aria-hidden="true">Screen-reader hidden text</div>
    <div style="display: none">CSS hidden content</div><script>secret script text</script>
    <footer>Footer navigation</footer></body></html>
    """
    text = extract_text(html)
    assert "family safety guide" in text
    assert "play with care" in text
    assert "unique password" in text
    for excluded in (
        "navigation noise",
        "hidden content",
        "screen-reader hidden text",
        "css hidden content",
        "secret script text",
        "footer navigation",
    ):
        assert excluded not in text

    malformed = extract_text("<main><h2>Broken but readable</h2><p>Keep accounts private.")
    assert "broken but readable" in malformed
    blocked = inspect_html_content(
        "<html><body><h1>Checking your browser</h1><p>Verify you are human.</p></body></html>"
    )
    assert blocked["available"] is False
    assert "will not bypass" in blocked["notice"]
    javascript_page = inspect_html_content(
        '<html><body><div id="root"></div><script src="/bundle.js"></script></body></html>'
    )
    assert javascript_page["available"] is False
    assert "does not run" in javascript_page["notice"]
    assert inspect_html_content("<html><body></body></html>")["available"] is False


def test_fetch_page_decodes_declared_charset_and_rejects_empty_or_non_html(
    monkeypatch,
):
    import artifacts.safelytics.security as security

    examples = [
        (
            "text/html; charset=windows-1252",
            "<html><body><h1>Café safety guide</h1><p>This is enough text to inspect the page.</p></body></html>".encode(
                "cp1252"
            ),
        ),
        (
            "text/html",
            '<html><head><meta charset="windows-1252"></head><body><h1>Café safety guide</h1><p>This is enough text to inspect the page.</p></body></html>'.encode(
                "cp1252"
            ),
        ),
    ]
    for content_type, body in examples:
        session = FakeSession(
            [FakeResponse(200, body=body, headers={"Content-Type": content_type})]
        )
        monkeypatch.setattr(security.requests, "Session", lambda session=session: session)
        fetched = fetch_page("https://example.com/", resolver=public_resolver)
        assert "Café safety guide" in fetched["html"]

    for response, message in (
        (
            FakeResponse(200, body=b"", headers={"Content-Type": "text/html"}),
            "empty response",
        ),
        (
            FakeResponse(
                200, body=b"%PDF", headers={"Content-Type": "application/pdf"}
            ),
            "not an HTML page",
        ),
    ):
        session = FakeSession([response])
        monkeypatch.setattr(security.requests, "Session", lambda session=session: session)
        with pytest.raises(FetchFailure, match=message):
            fetch_page("https://example.com/", resolver=public_resolver)


def test_analyze_marks_challenge_and_javascript_pages_unavailable(tmp_path, monkeypatch):
    database = tmp_path / "unreadable-pages.sqlite3"
    client = app_module.create_app(
        {"TESTING": True, "DATABASE": str(database)}
    ).test_client()
    pages = iter(
        [
            "<html><body><h1>Checking your browser</h1><p>Verify you are human.</p></body></html>",
            '<html><body><div id="root"></div><script src="/bundle.js"></script></body></html>',
        ]
    )
    monkeypatch.setattr(
        app_module,
        "fetch_page",
        lambda url: {
            "html": next(pages),
            "final_url": url,
            "redirect_chain": [],
            "notice": None,
        },
    )

    challenge = client.post("/analyze", data={"url": "https://example.com/"})
    assert b"human-verification page" in challenge.data
    assert b"Unknown" in challenge.data
    javascript = client.post("/analyze", data={"url": "https://example.com/"})
    assert b"does not run" in javascript.data
    scans = list_scans(path=database)
    assert len(scans) == 2
    assert all(scan["is_partial"] is True for scan in scans)
    assert all(scan["content"]["available"] is False for scan in scans)
