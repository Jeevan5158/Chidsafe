"""Safelytics child-safety and privacy analyzer."""
