"""Optional, lightweight browser-rendering fallback for client-side JavaScript pages.

By default, browser-based rendering is DISABLED to preserve lightweight, zero-dependency
local execution and avoid launching headless browser processes. When enabled via
the SAFELYTICS_ENABLE_BROWSER environment variable or Flask configuration, it applies
strict security boundaries:
1. SSRF check: The target host must resolve to a public IP before any browser process is launched.
2. Resource limits: A hard timeout (default 5s) and automatic process termination.
3. Sandboxed execution: Headless mode with disabled extensions and isolated contexts.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
from urllib.parse import urlsplit

from .security import UnsafeTarget, normalize_url, resolve_public_addresses

logger = logging.getLogger("safelytics.browser")

DEFAULT_BROWSER_TIMEOUT = 5  # seconds


def is_browser_fallback_enabled() -> bool:
    """Return True only if browser fallback has been explicitly opted into."""
    val = os.environ.get("SAFELYTICS_ENABLE_BROWSER", "").strip().lower()
    return val in {"1", "true", "yes", "on"}


def find_system_chrome() -> str | None:
    """Locate an installed Google Chrome / Chromium executable if present."""
    candidates = [
        os.environ.get("CHROME_PATH"),
        shutil.which("google-chrome"),
        shutil.which("chrome"),
        shutil.which("chromium"),
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    ]
    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate
    return None


def is_browser_fallback_available() -> bool:
    """Check if browser fallback is enabled AND an engine (Playwright or Chrome) exists."""
    if not is_browser_fallback_enabled():
        return False
    try:
        import playwright  # noqa: F401
        return True
    except ImportError:
        pass
    return find_system_chrome() is not None


def render_javascript_page(
    url: str,
    timeout_seconds: int = DEFAULT_BROWSER_TIMEOUT,
    resolver=None,
) -> dict:
    """Attempt to render a client-side JavaScript page with strict boundaries.

    Returns a dict with:
        "success": bool
        "html": str | None
        "error": str | None
        "engine": str | None ("playwright", "chrome-headless", or None)
    """
    if not is_browser_fallback_enabled():
        return {
            "success": False,
            "html": None,
            "error": "JavaScript browser rendering fallback is disabled by default.",
            "engine": None,
        }

    # Strict SSRF revalidation before launching any browser process
    normalized = normalize_url(url)
    parsed = urlsplit(normalized)
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        resolve_public_addresses(parsed.hostname or "", port, resolver=resolver)
    except (UnsafeTarget, Exception) as exc:
        return {
            "success": False,
            "html": None,
            "error": f"Security check rejected target address: {exc}",
            "engine": None,
        }

    # Strategy 1: Try Playwright if installed
    try:
        from playwright.sync_api import sync_playwright  # type: ignore

        logger.info("Attempting Playwright fallback render for %s", normalized)
        with sync_playwright() as playwright_ctx:
            browser = playwright_ctx.chromium.launch(
                headless=True,
                args=["--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage"],
            )
            try:
                context = browser.new_context(
                    user_agent="SafelyticsResearchBot/1.0 (+website safety analysis; optional browser rendering)",
                    bypass_csp=False,
                )
                page = context.new_page()
                page.goto(
                    normalized,
                    timeout=timeout_seconds * 1000,
                    wait_until="domcontentloaded",
                )
                html = page.content()
                return {
                    "success": True,
                    "html": html,
                    "error": None,
                    "engine": "playwright",
                }
            finally:
                browser.close()
    except ImportError:
        pass
    except Exception as exc:
        logger.warning("Playwright rendering failed for %s: %s", normalized, exc)
        return {
            "success": False,
            "html": None,
            "error": f"Playwright rendering failed: {exc}",
            "engine": "playwright",
        }

    # Strategy 2: Try Headless Chrome subprocess if available
    chrome_path = find_system_chrome()
    if chrome_path:
        logger.info("Attempting Headless Chrome dump-dom for %s", normalized)
        cmd = [
            chrome_path,
            "--headless=new",
            "--disable-gpu",
            "--no-sandbox",
            "--disable-extensions",
            "--disable-background-networking",
            "--disable-sync",
            "--disable-default-apps",
            "--mute-audio",
            f"--virtual-time-budget={max(1000, (timeout_seconds - 1) * 1000)}",
            "--dump-dom",
            normalized,
        ]
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout_seconds,
                encoding="utf-8",
                errors="replace",
            )
            if result.returncode == 0 and result.stdout.strip():
                return {
                    "success": True,
                    "html": result.stdout,
                    "error": None,
                    "engine": "chrome-headless",
                }
            return {
                "success": False,
                "html": None,
                "error": f"Chrome exited with code {result.returncode}",
                "engine": "chrome-headless",
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "html": None,
                "error": "Browser rendering timed out.",
                "engine": "chrome-headless",
            }
        except Exception as exc:
            return {
                "success": False,
                "html": None,
                "error": f"Chrome rendering error: {exc}",
                "engine": "chrome-headless",
            }

    return {
        "success": False,
        "html": None,
        "error": "No browser rendering engine is installed (requires Playwright or Chrome).",
        "engine": None,
    }
