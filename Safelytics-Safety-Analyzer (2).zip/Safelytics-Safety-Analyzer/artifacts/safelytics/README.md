# Safelytics

Safelytics is a rule-based website analyzer for families and other non-technical users. It checks child-content indicators separately from phishing, URL, redirect, and privacy indicators. A scan is an educational aid, not a guarantee that a site is safe or malicious.

## Run on Replit

The Replit workflow serves the Flask application with Gunicorn on the port supplied by Replit:

```bash
python -m gunicorn --workers 2 --threads 4 --timeout 45 --bind 0.0.0.0:${PORT:-5000} artifacts.safelytics.app:app
```

For local development, run `python -m artifacts.safelytics.app`. The app uses the existing blue Safelytics visual identity and its URL submission/results flow. No paid API, external service, or API key is needed.

## Local setup

From the repository root:

```bash
python -m pip install -r requirements.txt
python -m artifacts.safelytics.app
```

Open the local app on port 5000. The first app start creates the SQLite schema automatically.

## History and database

Scan records are stored in SQLite at `artifacts/safelytics/instance/safelytics.sqlite3`. Set `SAFELYTICS_DB_PATH` to use another writable location. History stores normalized scan addresses, timestamps, scores, findings, and analysis limitations; common secret-like query parameters are redacted before storage. No account, IP address, or other user profile is collected.

SQLite storage is local to this runtime. If the hosting environment does not preserve its writable filesystem between deployments, configure `SAFELYTICS_DB_PATH` to a persistent mounted location before relying on long-term history.

## Test and evaluate

Run automated tests:

```bash
pytest -q artifacts/safelytics/tests
```

Run the offline evaluation:

```bash
python -m artifacts.safelytics.evaluation
```

The labeled examples in `data/test_dataset.json` are synthetic, not verified websites. The evaluator reports precision, recall, false-positive rate, and false-negative rate for the configured rule threshold. Those metrics describe only this tiny fixture set and are not estimates of real-world detection quality.

## Scoring

`analysis.py` defines the configurable dimension weights and risk-category thresholds. It reports child-content, phishing/scam, domain/redirect, and privacy scores separately, then combines available dimensions into a weighted 0–10 summary. Missing evidence is excluded from the weighted calculation and shown as a limitation; an inaccessible page is not treated as clean content. Repeated identical findings do not add repeated points.

Child-content keyword matches affect the child-content suitability dimension only. They are not phishing, malware, or cyber-risk findings. A low score is not a safety guarantee.

## Safe-fetch boundaries

- Only HTTP and HTTPS on their standard ports are accepted.
- Local, private, reserved, and non-public DNS destinations are rejected.
- DNS is checked before each request, including every redirect destination.
- Redirects are followed manually with a five-hop limit; unsafe destinations are rejected.
- Requests do not use inherited proxy settings, do not bypass website controls, and time out.
- Response bodies are streamed and limited to 2 MiB. Non-HTML responses are not parsed.

The scanner checks static HTML and does not execute JavaScript, inspect browser network activity, confirm cookies actually set at runtime, or determine domain registration age. DNS can change after a lookup; the scanner rechecks each hop but does not claim to eliminate every network-level race.
