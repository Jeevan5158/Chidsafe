"""Small offline evaluation against explicitly synthetic examples."""

from __future__ import annotations

import json
from pathlib import Path

from .analysis import analyze_domain, analyze_phishing
from .security import normalize_url

DATASET_PATH = Path(__file__).resolve().parent / "data" / "test_dataset.json"
SUSPICIOUS_SCORE_THRESHOLD = 2.0


def compute_metrics(expected: list[str], predicted: list[str]) -> dict:
    if len(expected) != len(predicted):
        raise ValueError("Expected and predicted labels must have the same length.")
    true_positive = sum(
        actual == "suspicious" and guess == "suspicious"
        for actual, guess in zip(expected, predicted)
    )
    true_negative = sum(
        actual == "legitimate" and guess == "legitimate"
        for actual, guess in zip(expected, predicted)
    )
    false_positive = sum(
        actual == "legitimate" and guess == "suspicious"
        for actual, guess in zip(expected, predicted)
    )
    false_negative = sum(
        actual == "suspicious" and guess == "legitimate"
        for actual, guess in zip(expected, predicted)
    )

    def ratio(numerator: int, denominator: int) -> float:
        return round(numerator / denominator, 3) if denominator else 0.0

    return {
        "examples": len(expected),
        "true_positive": true_positive,
        "true_negative": true_negative,
        "false_positive": false_positive,
        "false_negative": false_negative,
        "precision": ratio(true_positive, true_positive + false_positive),
        "recall": ratio(true_positive, true_positive + false_negative),
        "false_positive_rate": ratio(
            false_positive, false_positive + true_negative
        ),
        "false_negative_rate": ratio(
            false_negative, false_negative + true_positive
        ),
        "threshold": SUSPICIOUS_SCORE_THRESHOLD,
        "dataset_note": (
            "Synthetic examples only; these metrics do not estimate performance "
            "on real websites."
        ),
    }


def evaluate_examples(examples: list[dict]) -> dict:
    expected = []
    predicted = []
    details = []
    for example in examples:
        url = normalize_url(example["url"])
        phishing = analyze_phishing(url, example.get("html", ""))
        domain = analyze_domain(url)
        cyber_score = max(phishing["risk_score"], domain["risk_score"])
        guess = "suspicious" if cyber_score >= SUSPICIOUS_SCORE_THRESHOLD else "legitimate"
        expected.append(example["label"])
        predicted.append(guess)
        details.append(
            {
                "id": example["id"],
                "label": example["label"],
                "prediction": guess,
                "score": cyber_score,
                "finding_titles": [
                    finding["title"]
                    for finding in phishing["findings"] + domain["findings"]
                ],
            }
        )
    return {"metrics": compute_metrics(expected, predicted), "details": details}


def evaluate_dataset(dataset_path: str | Path = DATASET_PATH) -> dict:
    with open(dataset_path, encoding="utf-8") as dataset_file:
        dataset = json.load(dataset_file)
    return evaluate_examples(dataset["examples"])


if __name__ == "__main__":
    print(json.dumps(evaluate_dataset(), indent=2))
