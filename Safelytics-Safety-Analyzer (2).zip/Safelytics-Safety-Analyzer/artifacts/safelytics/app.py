"""Flask web app for the Safelytics website safety analyzer."""

from __future__ import annotations

import logging
import os
import re
import sqlite3
from urllib.parse import urlsplit

from bs4 import BeautifulSoup
from flask import Flask, abort, render_template, request, send_from_directory

from .analysis import (
    analyze_domain,
    analyze_phishing,
    analyze_privacy,
    build_findings,
    annotate_finding_contributions,
    calculate_risk,
    classify_content,
    compare_scans,
    inspect_html_content,
)
from .security import FetchFailure, UnsafeTarget, fetch_page, normalize_url
from . import storage

logger = logging.getLogger("safelytics")

LEARNING_TOPICS = [
    {
        "id": "phishing",
        "title": "Phishing and tricky links",
        "text": (
            "Phishing is a trick that tries to get a password, payment detail, or "
            "other private information. A message can look urgent or use a name "
            "similar to a familiar company. Read the actual website name carefully; "
            "a picture or logo does not prove who sent the message."
        ),
        "example": "A made-up message says, “Your account will close today. Sign in at support.example.”",
    },
    {
        "id": "deceptive-links",
        "title": "Deceptive links and impersonation",
        "text": (
            "The words shown on a link can be different from the website it opens. "
            "Long addresses with many subdomains can also make the true site name "
            "harder to notice. When unsure, open the service from a saved bookmark "
            "or type its known address yourself."
        ),
        "example": "A link labelled “School portal” might lead to a different, unfamiliar website.",
    },
    {
        "id": "downloads",
        "title": "Unsafe downloads",
        "text": (
            "Files from unexpected messages or unfamiliar sites may contain harmful "
            "software. A familiar file icon or filename is not proof that a download "
            "is safe. Ask a trusted adult before opening an unexpected file."
        ),
        "example": "An unexpected “prize” file asks you to install a new player before it opens.",
    },
    {
        "id": "privacy",
        "title": "Privacy and tracking",
        "text": (
            "Some pages load pictures, scripts, or other resources from additional "
            "companies. That can reveal that a page was visited, but a static scan "
            "cannot tell exactly what information was collected or how it was used."
        ),
        "example": "A page includes an analytics resource hosted by a different company.",
    },
    {
        "id": "https",
        "title": "What HTTPS can and cannot tell you",
        "text": (
            "HTTPS encrypts the connection between your browser and a website. It "
            "does not prove that the website is honest, suitable for children, or "
            "careful with information."
        ),
        "example": "A misleading website can still show a lock icon and use HTTPS.",
    },
    {
        "id": "login-pages",
        "title": "Suspicious sign-in pages",
        "text": (
            "Pause before entering a password. Check the registered website name, "
            "look for unexpected urgency, and make sure the address is the one you "
            "meant to visit. Never send a password because a page asks you to hurry."
        ),
        "example": "A page asks for a password and says it will be deleted unless you act now.",
    },
    {
        "id": "cyberbullying",
        "title": "Bullying and harassment online",
        "text": (
            "Repeated insults, threats, or sharing hurtful posts are not your fault. "
            "Do not retaliate or confront the person. Tell a trusted adult, use the "
            "app's block and report tools, and keep useful account names and dates safely."
        ),
        "example": "A group chat keeps targeting one student after they ask for it to stop.",
    },
    {
        "id": "grooming-blackmail",
        "title": "Private images, grooming, and blackmail",
        "text": (
            "If someone asks for private images, threatens you, or says you must keep "
            "a relationship secret, tell a trusted adult right away. You are not to blame. "
            "Do not pay, send more images, meet them, reply with images, or forward abusive material."
        ),
        "example": "A person online threatens to share a private picture unless they receive money.",
    },
    {
        "id": "account-security",
        "title": "Passwords, passkeys, and one-time codes",
        "text": (
            "Use a unique password or passkey for each important account and turn on "
            "multi-factor authentication when available. Never share an OTP or recovery "
            "code, even with someone claiming to be support. Recover accounts only through "
            "the official app or a known website."
        ),
        "example": "A caller says they need your OTP to stop a game account from closing.",
    },
    {
        "id": "scams",
        "title": "Gaming, QR, payment, and impersonation scams",
        "text": (
            "A free game reward, fake job offer, QR code, or urgent payment request can "
            "be a scam. Check with the real company or person using a contact you already "
            "trust. Do not pay or share passwords, codes, or bank details to claim a prize or job."
        ),
        "example": "A message using a friend's photo asks you to scan a QR code to receive money.",
    },
    {
        "id": "oversharing",
        "title": "Share less personal information",
        "text": (
            "Think before posting your full name, phone number, home or school address, "
            "daily route, live location, or private photos. A private account does not "
            "guarantee that posts will stay private. Ask a trusted adult if unsure."
        ),
        "example": "A public post shows a school badge and the time you leave for home.",
    },
    {
        "id": "after-an-incident",
        "title": "If something online has gone wrong",
        "text": (
            "Pause and tell a trusted adult; asking for help is the right step. Block and "
            "report the account. Keep useful details such as the account name, web address, "
            "date, or payment reference safely, but never forward abusive or intimate images. "
            "If money or an account is at risk, contact the bank or service from a trusted device."
        ),
        "example": "A person sends a threatening message and asks you not to tell anyone.",
    },
]

QUIZ_QUESTIONS = [
    {
        "id": "https",
        "topic": "HTTPS",
        "question": "A page uses HTTPS. What does that tell you?",
        "choices": [
            ("safe", "The site is definitely honest and safe."),
            ("encrypted", "The connection is encrypted, but the site still needs checking."),
            ("nothing", "It tells you nothing about the connection."),
        ],
        "answer": "encrypted",
        "feedback": (
            "Correct. HTTPS protects the connection, but it does not prove the site is honest "
            "or suitable for children."
        ),
        "correction": (
            "Not quite. HTTPS encrypts the connection, but it does not prove the site is honest "
            "or suitable for children."
        ),
    },
    {
        "id": "password",
        "topic": "Sign-in pages",
        "question": "An unexpected page says “Act now” and asks for your password. What should you do?",
        "choices": [
            ("enter", "Enter it quickly so the account is not closed."),
            ("pause", "Pause and check the site with a trusted adult or known bookmark."),
            ("reuse", "Try a different password on the same page."),
        ],
        "answer": "pause",
        "feedback": (
            "Correct. Urgent pressure and unexpected password requests are reasons to stop and verify."
        ),
        "correction": (
            "Choose “pause.” Do not enter any password until the website has been checked."
        ),
    },
    {
        "id": "trackers",
        "topic": "Privacy checks",
        "question": "A scan sees an analytics address in a page. What can it conclude?",
        "choices": [
            ("proof", "It proves exactly what personal information was collected."),
            ("reference", "The page references that service; collection details are unknown."),
            ("malware", "The page is definitely malware."),
        ],
        "answer": "reference",
        "feedback": (
            "Correct. Static HTML can show a reference, not the full behavior or data collection."
        ),
        "correction": (
            "The scan can report a reference, but cannot establish collection details or prove malware."
        ),
    },
    {
        "id": "cyberbullying",
        "topic": "Bullying online",
        "question": "A group keeps sending hurtful messages. What is a safe next step?",
        "choices": [
            ("retaliate", "Send threats back so they stop."),
            ("help", "Tell a trusted adult, then block and report the accounts."),
            ("forward", "Forward the messages and any private images to more people."),
        ],
        "answer": "help",
        "feedback": "Correct. Ask a trusted adult for help and use the platform's block and report tools.",
        "correction": "Do not retaliate or spread the material. Tell a trusted adult and block/report the accounts.",
    },
    {
        "id": "rewards",
        "topic": "Gaming and payment scams",
        "question": "A game message promises a free prize if you scan a QR code and pay a small fee. What should you do?",
        "choices": [
            ("pay", "Pay quickly before the prize expires."),
            ("check", "Do not scan or pay; check with a trusted adult through an official source."),
            ("credentials", "Send your password so the prize can be added."),
        ],
        "answer": "check",
        "feedback": "Correct. Verify rewards and payment requests independently; never share your password.",
        "correction": "Do not scan or pay. Check the offer with a trusted adult and the official game service.",
    },
    {
        "id": "otp",
        "topic": "Passwords and OTPs",
        "question": "Someone claiming to be support asks you to read them a one-time code. What should you do?",
        "choices": [
            ("share", "Share it if they know your username."),
            ("refuse", "Never share the code; tell a trusted adult and use the official account app."),
            ("post", "Post it in the game chat so a moderator can see it."),
        ],
        "answer": "refuse",
        "feedback": "Correct. One-time and recovery codes are secret; use only the official account recovery process.",
        "correction": "Never share an OTP or recovery code. Get help from a trusted adult and use the official app or site.",
    },
    {
        "id": "financial-fraud",
        "topic": "Financial fraud in India",
        "question": "Money was taken after a suspicious online payment. What should your family do first?",
        "choices": [
            ("wait", "Wait several days to see what happens."),
            ("bank", "Tell a trusted adult, contact the bank/payment provider promptly, and call 1930."),
            ("reply", "Reply to the person who took the money and send more details."),
        ],
        "answer": "bank",
        "feedback": "Correct. Contact the bank/payment provider promptly and report financial cyber fraud at 1930.",
        "correction": "Tell a trusted adult, contact the bank/payment provider promptly, and call 1930 to report financial cyber fraud.",
    },
    {
        "id": "ask-help",
        "topic": "Getting help",
        "question": "Someone threatens to share a private image unless you pay. What is the safest response?",
        "choices": [
            ("pay", "Pay and send another image to make the threat stop."),
            ("help", "You are not to blame; tell a trusted adult, do not pay or forward images, and block/report."),
            ("confront", "Meet or confront the person alone."),
        ],
        "answer": "help",
        "feedback": "Correct. You are not to blame. Get help from a trusted adult and do not pay, send more images, or forward material.",
        "correction": "Do not pay or confront them. Tell a trusted adult, block/report the account, and do not forward private material.",
    },
]


def _overview(html: str | None, url: str) -> str:
    if html is None:
        return "Page text was unavailable, so Safelytics could not prepare a content overview."
    try:
        soup = BeautifulSoup(html, "lxml")
    except Exception:
        soup = BeautifulSoup(html, "html.parser")

    for tag in soup(["script", "style", "noscript", "nav", "footer", "header", "aside"]):
        tag.decompose()

    paragraphs = [
        " ".join(paragraph.stripped_strings)
        for paragraph in soup.find_all(["p", "article"])
        if len(" ".join(paragraph.stripped_strings)) >= 40
    ]
    if paragraphs:
        sentences = []
        for sentence in re.split(r"(?<=[.!?])\s+", " ".join(paragraphs)):
            sentence = sentence.strip()
            if len(sentence) >= 40 and sentence[:60].lower() not in {
                item[:60].lower() for item in sentences
            }:
                sentences.append(sentence)
            if len(sentences) == 3:
                break
        overview = " ".join(sentences)
        if len(overview) > 320:
            overview = overview[:320].rsplit(" ", 1)[0] + "…"
        if overview:
            return overview

    # Check meta description
    desc_tag = soup.find("meta", attrs={"name": re.compile(r"^description$", re.I)})
    if not desc_tag:
        desc_tag = soup.find("meta", attrs={"property": re.compile(r"^og:description$", re.I)})
    if desc_tag and desc_tag.get("content"):
        meta_text = desc_tag["content"].strip()
        if len(meta_text) >= 20:
            if len(meta_text) > 320:
                meta_text = meta_text[:320].rsplit(" ", 1)[0] + "…"
            return meta_text

    hostname = urlsplit(url).hostname or ""
    if any(part in hostname for part in ("wikipedia", "britannica", "encyclopedia")):
        return "This page appears to contain informational or encyclopedic content."
    if any(part in hostname for part in (".edu", "university", "college", "school")):
        return "This page appears to be related to academic or institutional services."
    return "No readable page overview was available in the scanned HTML."


def _recommendation(level: str) -> str:
    return {
        "Low Risk": "No major rule-based warning was found. This is not a guarantee of safety.",
        "Warning": "Review the findings with a trusted adult before sharing information.",
        "High Risk": "Do not enter personal information until the website is independently verified.",
        "Unknown": "There is not enough page evidence for a reliable assessment. Review it manually.",
    }.get(level, "Review the findings carefully.")


def _empty_analysis_scan(
    url: str,
    error_message: str | None = None,
    redirect_chain: list[dict] | None = None,
    final_url: str | None = None,
    extraction_status: str = "inaccessible_or_blocked",
    uncompleted_checks: list[str] | None = None,
    http_status: int | None = None,
) -> dict:
    """Build a full URL-only report if the remote page cannot be fetched or read."""
    content = classify_content("", available=False)
    phishing = analyze_phishing(url, None)
    domain = analyze_domain(url, redirect_chain, final_url)
    privacy = analyze_privacy(url, None)
    if not privacy["available"] and privacy["is_https"]:
        privacy["privacy_score"] = None
    risk = calculate_risk(content, phishing, domain, privacy)
    if risk["risk_level"] == "Low Risk":
        risk["risk_level"], risk["risk_color"] = "Unknown", "grey"

    uncompleted = list(uncompleted_checks) if uncompleted_checks else [
        "Child-content safety keyword scan (page content unavailable)",
        "Page-level tracking and third-party resource analysis (page markup unavailable)",
        "In-page credential form and sensitive input inspection (page markup unavailable)",
        "Page content overview (readable text unavailable)",
    ]

    limitations = [
        "Page content could not be downloaded, so child-content and page privacy checks are incomplete.",
        "Domain registration age is unavailable and was not inferred.",
        "Static HTML checks cannot establish all browser behavior or data collection.",
    ]
    if error_message:
        limitations.insert(0, error_message)
    findings = annotate_finding_contributions(
        build_findings(content, phishing, domain, privacy), risk["score_breakdown"]
    )
    return {
        **risk,
        "url": url,
        "normalized_url": url,
        "content": content,
        "phishing": phishing,
        "domain": domain,
        "privacy": privacy,
        "findings": findings,
        "limitations": limitations,
        "uncompleted_checks": uncompleted,
        "extraction_status": extraction_status,
        "http_status": http_status,
        "is_partial": True,
        "fetch_notice": error_message or "The page could not be downloaded.",
        "overview": _overview(None, url),
        "recommendation": _recommendation(risk["risk_level"]),
    }


def _scan_url(url: str) -> dict:
    fetch_error = None
    html = None
    final_url = None
    redirect_chain = None
    failure_type = "inaccessible"
    http_status = None
    is_truncated = False
    fetched = None

    try:
        fetched = fetch_page(url)
        html = fetched["html"]
        final_url = fetched["final_url"]
        redirect_chain = fetched["redirect_chain"]
        is_truncated = fetched.get("is_truncated", False)
        http_status = fetched.get("status_code", 200)
    except UnsafeTarget:
        raise
    except FetchFailure as exc:
        fetch_error = str(exc)
        redirect_chain = exc.redirect_chain
        final_url = exc.final_url
        failure_type = getattr(exc, "failure_type", "inaccessible")
        http_status = getattr(exc, "status_code", None)
    except Exception:
        logger.exception("Unexpected failure while fetching a scan target")
        fetch_error = "The page could not be analyzed because an unexpected fetch error occurred."
        failure_type = "network_error"

    if html is None:
        status_map = {
            "unsupported_type": "unsupported_type",
            "challenge": "challenge",
            "empty_response": "empty",
        }
        extraction_status = status_map.get(failure_type, "inaccessible_or_blocked")
        return _empty_analysis_scan(
            url,
            fetch_error,
            redirect_chain,
            final_url,
            extraction_status=extraction_status,
            http_status=http_status,
        )

    notice_from_fetch = fetched.get("notice") if fetched else None
    inspection = inspect_html_content(
        html,
        is_truncated=is_truncated,
        fetch_notice=notice_from_fetch,
    )

    if not inspection["available"]:
        # Check if browser rendering fallback is enabled and justified
        if inspection.get("status") == "javascript_required":
            try:
                from .browser import is_browser_fallback_enabled, render_javascript_page

                if is_browser_fallback_enabled():
                    browser_res = render_javascript_page(final_url or url)
                    if browser_res.get("success") and browser_res.get("html"):
                        rendered_inspection = inspect_html_content(
                            browser_res["html"],
                            fetch_notice="Page rendered using optional local headless browser fallback.",
                        )
                        if rendered_inspection["available"]:
                            html = browser_res["html"]
                            inspection = rendered_inspection
            except Exception as b_exc:
                logger.warning("Browser fallback execution failed: %s", b_exc)

    if not inspection["available"]:
        status_map = {
            "challenge": "challenge",
            "javascript_required": "javascript_required",
            "empty": "empty",
        }
        extraction_status = status_map.get(
            inspection.get("status"), "inaccessible_or_blocked"
        )
        return _empty_analysis_scan(
            url,
            inspection["notice"],
            redirect_chain,
            final_url,
            extraction_status=extraction_status,
            uncompleted_checks=inspection.get("uncompleted_checks"),
            http_status=http_status,
        )

    content = classify_content(inspection["text"], available=True)
    phishing = analyze_phishing(url, html)
    domain = analyze_domain(url, redirect_chain, final_url)
    privacy = analyze_privacy(url, html, page_url=final_url)
    risk = calculate_risk(content, phishing, domain, privacy)

    extraction_status = "partially_retrieved" if is_truncated else "success"
    uncompleted = (
        ["Remaining content beyond 2 MiB was not analyzed (truncated)."]
        if is_truncated
        else []
    )

    limitations = [
        "This scan uses static HTML and transparent keyword/domain rules; it does not execute JavaScript.",
        "A low score is not a guarantee that the site is safe.",
        "Domain registration age is unavailable and was not inferred.",
        "Tracker references and script counts do not establish the amount of data collected.",
    ]
    if is_truncated:
        limitations.insert(
            0,
            "The page exceeded the 2 MiB limit and was partially retrieved (truncated).",
        )

    findings = annotate_finding_contributions(
        build_findings(content, phishing, domain, privacy), risk["score_breakdown"]
    )
    return {
        **risk,
        "url": url,
        "normalized_url": url,
        "content": content,
        "phishing": phishing,
        "domain": domain,
        "privacy": privacy,
        "findings": findings,
        "limitations": limitations,
        "uncompleted_checks": uncompleted,
        "extraction_status": extraction_status,
        "http_status": http_status,
        "is_partial": is_truncated,
        "fetch_notice": inspection.get("notice"),
        "overview": _overview(html, url),
        "recommendation": _recommendation(risk["risk_level"]),
    }


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.update(
        MAX_CONTENT_LENGTH=8 * 1024,
        DATABASE=str(storage.database_path()),
        HISTORY_AVAILABLE=True,
    )
    if test_config:
        app.config.update(test_config)

    try:
        storage.initialize_database(app.config["DATABASE"])
    except (sqlite3.Error, OSError):
        logger.exception("SQLite initialization failed")
        app.config["HISTORY_AVAILABLE"] = False

    @app.route("/manifest.json")
    def manifest():
        return send_from_directory(
            app.static_folder, "manifest.json", mimetype="application/manifest+json"
        )

    @app.route("/service-worker.js")
    def service_worker():
        response = send_from_directory(
            app.static_folder, "service-worker.js", mimetype="application/javascript"
        )
        response.headers["Service-Worker-Allowed"] = "/"
        return response

    @app.route("/", methods=["GET"])
    def index():
        return render_template(
            "index.html",
            error=request.args.get("error"),
            history_available=app.config["HISTORY_AVAILABLE"],
        )

    @app.route("/analyze", methods=["POST"])
    def analyze():
        raw_url = request.form.get("url", "")
        try:
            normalized_url = normalize_url(raw_url)
        except UnsafeTarget as exc:
            return render_template(
                "index.html",
                error=str(exc),
                history_available=app.config["HISTORY_AVAILABLE"],
            ), 400

        try:
            scan = _scan_url(normalized_url)
        except UnsafeTarget as exc:
            return render_template(
                "index.html",
                error=str(exc),
                history_available=app.config["HISTORY_AVAILABLE"],
            ), 400

        history_notice = None
        try:
            scan_id = storage.save_scan(scan, app.config["DATABASE"])
            scan["id"] = scan_id
            app.config["HISTORY_AVAILABLE"] = True
        except (sqlite3.Error, OSError, ValueError):
            logger.exception("Failed to save scan history")
            app.config["HISTORY_AVAILABLE"] = False
            history_notice = "This scan is shown, but it could not be saved to scan history."

        return render_template(
            "result.html",
            **scan,
            history_notice=history_notice,
            history_available=app.config["HISTORY_AVAILABLE"],
        )

    @app.route("/history", methods=["GET"])
    def history():
        error_message = None
        scans = []
        try:
            scans = storage.list_scans(path=app.config["DATABASE"])
        except (sqlite3.Error, OSError):
            logger.exception("Failed to read scan history")
            error_message = "Scan history is temporarily unavailable."
        return render_template(
            "history.html",
            scans=scans,
            error=error_message,
            history_available=app.config["HISTORY_AVAILABLE"],
        )

    @app.route("/compare", methods=["GET", "POST"])
    def compare():
        scan_a = request.values.get("scan_a", "")
        scan_b = request.values.get("scan_b", "")
        comparison = None
        error_message = None
        if scan_a or scan_b:
            if not scan_a or not scan_b:
                error_message = "Choose both saved scans to compare."
            else:
                try:
                    scan_a_id = int(scan_a)
                    scan_b_id = int(scan_b)
                except ValueError:
                    error_message = "Choose two valid scans from the saved scan list."
                else:
                    if scan_a_id < 1 or scan_b_id < 1:
                        error_message = "Choose two valid scans from the saved scan list."
                    elif scan_a_id == scan_b_id:
                        error_message = "Choose two different saved scans."
                    else:
                        try:
                            first = storage.get_scan(scan_a_id, app.config["DATABASE"])
                            second = storage.get_scan(scan_b_id, app.config["DATABASE"])
                        except (ValueError, TypeError, sqlite3.Error, OSError):
                            logger.exception("Unable to load the requested comparison scans")
                            error_message = (
                                "One of those saved scans is incomplete or could not be loaded."
                            )
                        else:
                            if first is None or second is None:
                                error_message = (
                                    "One of those scans is no longer available. Choose another."
                                )
                            else:
                                try:
                                    comparison = compare_scans(first, second)
                                except ValueError as exc:
                                    error_message = str(exc)
        try:
            scans = storage.list_scans(path=app.config["DATABASE"])
        except (ValueError, TypeError, sqlite3.Error, OSError):
            logger.exception("Failed to load scans for comparison")
            scans = []
            error_message = error_message or "Scan history is temporarily unavailable."
        return render_template(
            "compare.html",
            scans=scans,
            comparison=comparison,
            scan_a=scan_a,
            scan_b=scan_b,
            error=error_message,
            history_available=app.config["HISTORY_AVAILABLE"],
        )

    @app.route("/learn", methods=["GET", "POST"])
    def learn():
        answered_id = None
        selected_answer = None
        question_result = None
        if request.method == "POST":
            answered_id = request.form.get("question_id", "")
            selected_answer = request.form.get("answer", "")
            selected_question = next(
                (question for question in QUIZ_QUESTIONS if question["id"] == answered_id),
                None,
            )
            if selected_question is None:
                abort(400, description="Choose a quiz question from this page.")
            is_correct = selected_answer == selected_question["answer"]
            question_result = {
                "id": answered_id,
                "is_correct": is_correct,
                "message": (
                    selected_question["feedback"]
                    if is_correct else selected_question["correction"]
                ),
            }

        return render_template(
            "learn.html",
            topics=LEARNING_TOPICS,
            quiz_questions=QUIZ_QUESTIONS,
            answered_id=answered_id,
            selected_answer=selected_answer,
            question_result=question_result,
            history_available=app.config["HISTORY_AVAILABLE"],
        )

    @app.errorhandler(413)
    def request_too_large(_error):
        return render_template(
            "index.html",
            error="The submitted form is too large. Enter a website address only.",
            history_available=app.config["HISTORY_AVAILABLE"],
        ), 413

    @app.errorhandler(500)
    def internal_error(_error):
        logger.exception("Unhandled Safelytics application error")
        return render_template("error.html"), 500

    return app


app = create_app()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
