self.addEventListener("install", (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// Safelytics does not cache scan results or submitted URLs.
self.addEventListener("fetch", () => {});
