"""Strict URL handling and bounded, redirect-aware public-web fetching."""

from __future__ import annotations

import ipaddress
import re
import socket
from urllib.parse import urljoin, urlsplit, urlunsplit

import requests
from bs4 import UnicodeDammit

MAX_REDIRECTS = 5
MAX_URL_LENGTH = 2048
MAX_BODY_BYTES = 2 * 1024 * 1024
REQUEST_TIMEOUT = (4, 7)
USER_AGENT = "SafelyticsResearchBot/1.0 (+website safety analysis)"
REDIRECT_CODES = {301, 302, 303, 307, 308}


class UnsafeTarget(ValueError):
    """The requested address is outside the scanner's allowed URL policy."""


class FetchFailure(RuntimeError):
    """A remote website could not be fetched within the scanner's limits."""

    def __init__(
        self,
        message: str,
        *,
        redirect_chain: list[dict] | None = None,
        final_url: str | None = None,
        failure_type: str = "inaccessible",
        status_code: int | None = None,
    ) -> None:
        super().__init__(message)
        self.redirect_chain = (
            [dict(hop) for hop in redirect_chain]
            if redirect_chain is not None
            else None
        )
        self.final_url = final_url
        self.failure_type = failure_type
        self.status_code = status_code


def normalize_url(raw_url: str) -> str:
    """Validate URL syntax and return a normalized HTTP(S) URL.

    DNS checks are intentionally performed immediately before every network hop
    by ``fetch_page``; this function is also safe to use for local analysis and
    storing scan identifiers without making a network request.
    """
    if not isinstance(raw_url, str):
        raise UnsafeTarget("Enter a website address.")
    value = raw_url.strip()
    if not value:
        raise UnsafeTarget("Enter a website address.")
    if len(value) > MAX_URL_LENGTH:
        raise UnsafeTarget("The website address is too long.")
    if any(character.isspace() or ord(character) < 32 for character in value):
        raise UnsafeTarget("The website address cannot contain spaces or control characters.")
    if "\\" in value:
        raise UnsafeTarget("The website address contains an invalid character.")
    if "://" not in value:
        value = f"https://{value}"

    try:
        parsed = urlsplit(value)
        scheme = parsed.scheme.lower()
        hostname = parsed.hostname
        port = parsed.port
    except ValueError as exc:
        raise UnsafeTarget("The website address is not valid.") from exc

    if scheme not in {"http", "https"}:
        raise UnsafeTarget("Only HTTP and HTTPS website addresses can be analyzed.")
    if not hostname:
        raise UnsafeTarget("Enter a complete website address, such as example.com.")
    if parsed.username is not None or parsed.password is not None:
        raise UnsafeTarget("Website addresses containing usernames or passwords are not accepted.")

    try:
        address = ipaddress.ip_address(hostname)
        normalized_host = address.compressed.lower()
    except ValueError:
        if "%" in hostname:
            raise UnsafeTarget("The website hostname is not valid.")
        try:
            normalized_host = hostname.rstrip(".").encode("idna").decode("ascii").lower()
        except UnicodeError as exc:
            raise UnsafeTarget("The website hostname is not valid.") from exc
        if "." not in normalized_host:
            raise UnsafeTarget("Enter a public website name, such as example.com.")
        if normalized_host in {"localhost", "metadata.google.internal"} or normalized_host.endswith(
            (".localhost", ".local", ".internal", ".lan", ".home", ".test")
        ):
            raise UnsafeTarget("Local and internal network addresses cannot be analyzed.")

    expected_port = 443 if scheme == "https" else 80
    if port is not None and port != expected_port:
        raise UnsafeTarget("Only the standard HTTP and HTTPS ports can be analyzed.")

    rendered_host = f"[{normalized_host}]" if ":" in normalized_host else normalized_host
    netloc = rendered_host
    path = parsed.path or "/"
    return urlunsplit((scheme, netloc, path, parsed.query, ""))


def resolve_public_addresses(hostname: str, port: int, resolver=None) -> list[str]:
    """Resolve a host and reject the entire answer if any address is non-public."""
    try:
        literal = ipaddress.ip_address(hostname)
    except ValueError:
        literal = None

    if literal is not None:
        addresses = [literal]
    else:
        lookup = resolver or socket.getaddrinfo
        try:
            results = lookup(hostname, port, type=socket.SOCK_STREAM)
        except (OSError, socket.gaierror) as exc:
            raise FetchFailure("The website hostname could not be resolved.") from exc
        addresses = []
        for result in results:
            sockaddr = result[4]
            try:
                addresses.append(ipaddress.ip_address(sockaddr[0]))
            except (ValueError, IndexError, TypeError):
                raise UnsafeTarget("The website resolved to an invalid network address.")

    if not addresses:
        raise FetchFailure("The website hostname did not resolve to an address.")
    if any(not address.is_global for address in addresses):
        raise UnsafeTarget("The website points to a private or reserved network address.")
    return sorted({address.compressed for address in addresses})


def fetch_page(url: str, resolver=None) -> dict:
    """Fetch an HTML page while validating every redirect destination.

    Requests are never allowed to follow redirects automatically. Each target
    is parsed and its DNS answers are checked again before the next request.
    The fetched body is streamed with a hard size limit.
    """
try:
    import charset_normalizer
except ImportError:
    charset_normalizer = None


def decode_html_bytes(body: bytes, content_type: str = "") -> tuple[str, str]:
    """Decode HTML bytes with high resilience against encoding mismatches and Mojibake.

    Returns: (decoded_unicode_text, detected_encoding_name)
    """
    if not body:
        return "", "utf-8"

    # 1. Byte Order Marks
    if body.startswith(b"\xef\xbb\xbf"):
        try:
            return body[3:].decode("utf-8"), "utf-8-sig"
        except UnicodeDecodeError:
            pass
    elif body.startswith(b"\xff\xfe"):
        try:
            return body[2:].decode("utf-16-le"), "utf-16-le"
        except UnicodeDecodeError:
            pass
    elif body.startswith(b"\xfe\xff"):
        try:
            return body[2:].decode("utf-16-be"), "utf-16-be"
        except UnicodeDecodeError:
            pass

    # 2. Extract declared charset from HTML meta tag in initial bytes
    meta_charset = None
    meta_match = re.search(
        rb"""<meta[^>]+(?:charset\s*=\s*["']?([a-zA-Z0-9_\-]+)|content\s*=\s*["'][^"']*charset=([a-zA-Z0-9_\-]+))""",
        body[:4096],
        re.IGNORECASE,
    )
    if meta_match:
        raw_enc = meta_match.group(1) or meta_match.group(2)
        if raw_enc:
            meta_charset = raw_enc.decode("ascii", errors="ignore").strip().lower()

    # 3. Extract declared charset from HTTP header
    http_charset = None
    declared = re.search(r"charset\s*=\s*[\"']?([^;\"'\s]+)", content_type, re.IGNORECASE)
    if declared:
        http_charset = declared.group(1).strip().lower()

    # 4. Check UTF-8 validity
    # Many servers send ISO-8859-1 in HTTP headers by default even when the document is UTF-8.
    # If the document is valid UTF-8 and either meta specifies UTF-8 or contains non-ASCII sequences,
    # prefer UTF-8 to prevent Mojibake.
    try:
        utf8_text = body.decode("utf-8")
        if meta_charset in {"utf-8", "utf8"} or http_charset in {"utf-8", "utf8"}:
            return utf8_text, "utf-8"
        if not meta_charset or meta_charset in {"utf-8", "utf8"}:
            return utf8_text, "utf-8"
    except UnicodeDecodeError:
        pass

    # 5. Try HTML meta declared charset
    if meta_charset:
        try:
            return body.decode(meta_charset), meta_charset
        except (LookupError, UnicodeDecodeError):
            pass

    # 6. Try HTTP header declared charset
    if http_charset:
        try:
            return body.decode(http_charset), http_charset
        except (LookupError, UnicodeDecodeError):
            pass

    # 7. Try charset-normalizer (already installed, robust statistical detection)
    if charset_normalizer is not None:
        try:
            best_match = charset_normalizer.from_bytes(body).best()
            if best_match and best_match.encoding:
                return str(best_match), best_match.encoding
        except Exception:
            pass

    # 8. Try BeautifulSoup's UnicodeDammit
    detected = UnicodeDammit(body, is_html=True)
    if detected.unicode_markup:
        return detected.unicode_markup, detected.original_encoding or "dammit"

    # 9. Fallback safely to UTF-8 with replacement
    return body.decode("utf-8", errors="replace"), "utf-8-replace"


def _decode_html_body(body: bytes, content_type: str) -> str:
    """Backwards-compatible wrapper returning decoded string."""
    text, _ = decode_html_bytes(body, content_type)
    return text


def _friendly_network_error(exc: requests.RequestException) -> str:
    if isinstance(exc, requests.Timeout):
        return "The website did not respond before the scan timed out."
    if isinstance(exc, requests.exceptions.SSLError):
        return "The website TLS/SSL security certificate could not be verified."
    if isinstance(exc, requests.ConnectionError):
        return "The website could not be reached. It may be offline or blocking automated access."
    return "The website could not be analyzed because the network request failed."


def _network_failure_type(exc: requests.RequestException) -> str:
    if isinstance(exc, requests.Timeout):
        return "timeout"
    if isinstance(exc, requests.exceptions.SSLError):
        return "ssl_error"
    if isinstance(exc, requests.ConnectionError):
        return "connection_error"
    return "network_error"


def fetch_page(url: str, resolver=None) -> dict:
    """Fetch an HTML page while validating every redirect destination.

    Requests are never allowed to follow redirects automatically. Each target
    is parsed and its DNS answers are checked again before the next request.
    The fetched body is streamed with a hard size limit (2 MiB). If a page
    exceeds the limit, it is safely truncated and flagged as partial rather
    than aborting completely.
    """
    current_url = normalize_url(url)
    redirect_chain = []
    session = requests.Session()
    session.trust_env = False
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
    }

    try:
        for hop in range(MAX_REDIRECTS + 1):
            parsed = urlsplit(current_url)
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
            try:
                resolve_public_addresses(parsed.hostname or "", port, resolver=resolver)
            except UnsafeTarget as exc:
                if not redirect_chain:
                    raise
                redirect_chain[-1]["blocked"] = True
                raise FetchFailure(
                    "A redirect to a private or reserved network destination was blocked.",
                    redirect_chain=redirect_chain,
                    final_url=redirect_chain[-1]["source"],
                    failure_type="blocked",
                ) from exc
            except FetchFailure as exc:
                if not redirect_chain:
                    raise
                redirect_chain[-1]["blocked"] = True
                raise FetchFailure(
                    "A redirect destination could not be verified, so it was not visited.",
                    redirect_chain=redirect_chain,
                    final_url=redirect_chain[-1]["source"],
                    failure_type="dns_error",
                ) from exc

            try:
                response = session.get(
                    current_url,
                    headers=headers,
                    timeout=REQUEST_TIMEOUT,
                    allow_redirects=False,
                    stream=True,
                )
            except requests.RequestException as exc:
                last_reached = redirect_chain[-1]["source"] if redirect_chain else None
                raise FetchFailure(
                    _friendly_network_error(exc),
                    redirect_chain=redirect_chain or None,
                    final_url=last_reached,
                    failure_type=_network_failure_type(exc),
                ) from exc

            try:
                if redirect_chain and redirect_chain[-1]["destination"] == current_url:
                    redirect_chain[-1]["followed"] = True

                if response.status_code in REDIRECT_CODES:
                    location = response.headers.get("Location")
                    if not location:
                        raise FetchFailure(
                            "The website returned an incomplete redirect.",
                            redirect_chain=redirect_chain,
                            final_url=current_url,
                            failure_type="redirect_error",
                            status_code=response.status_code,
                        )
                    if hop >= MAX_REDIRECTS:
                        redirect_chain.append(
                            {
                                "source": current_url,
                                "status_code": response.status_code,
                                "destination": "[redirect limit reached]",
                                "blocked": True,
                                "followed": False,
                            }
                        )
                        raise FetchFailure(
                            "The website redirected too many times; the next destination was not visited.",
                            redirect_chain=redirect_chain,
                            final_url=current_url,
                            failure_type="redirect_limit",
                            status_code=response.status_code,
                        )
                    try:
                        destination = normalize_url(urljoin(current_url, location))
                    except UnsafeTarget as exc:
                        redirect_chain.append(
                            {
                                "source": current_url,
                                "status_code": response.status_code,
                                "destination": "[blocked destination]",
                                "blocked": True,
                                "followed": False,
                            }
                        )
                        raise FetchFailure(
                            "A redirect target was not an allowed public HTTP(S) address.",
                            redirect_chain=redirect_chain,
                            final_url=current_url,
                            failure_type="blocked",
                            status_code=response.status_code,
                        ) from exc
                    redirect_chain.append(
                        {
                            "source": current_url,
                            "status_code": response.status_code,
                            "destination": destination,
                            "blocked": False,
                            "followed": False,
                        }
                    )
                    current_url = destination
                    continue

                if response.status_code >= 400:
                    status = response.status_code
                    # Inspect initial bytes of error body for human challenge markers
                    error_bytes = bytearray()
                    try:
                        for chunk in response.iter_content(chunk_size=4096):
                            if chunk:
                                error_bytes.extend(chunk)
                            if len(error_bytes) >= 16384:
                                break
                    except Exception:
                        pass

                    error_text = bytes(error_bytes).decode("utf-8", errors="replace").lower()
                    challenge_markers = (
                        "verify you are human",
                        "checking your browser",
                        "complete the captcha",
                        "complete the security check",
                        "automated requests are not allowed",
                        "enable javascript and cookies",
                        "cf-chl-",
                        "cloudflare ray id",
                        "attention required! | cloudflare",
                        "turnstile",
                        "ddos protection by cloudflare",
                    )
                    if any(marker in error_text for marker in challenge_markers):
                        raise FetchFailure(
                            f"The website returned an access-denied or human-verification page (HTTP {status}). Safelytics will not bypass it.",
                            redirect_chain=redirect_chain,
                            final_url=current_url,
                            failure_type="challenge",
                            status_code=status,
                        )

                    if status == 401:
                        message = "This website requires sign-in; Safelytics cannot inspect it without access."
                        failure_type = "auth_required"
                    elif status == 403:
                        message = "This website blocks automated requests (403 Forbidden)."
                        failure_type = "blocked"
                    elif status == 404:
                        message = "The requested page was not found (404)."
                        failure_type = "not_found"
                    elif status == 429:
                        message = "This website is temporarily limiting requests (429)."
                        failure_type = "rate_limited"
                    elif status >= 500:
                        message = f"The website returned an HTTP {status} response."
                        failure_type = "server_error"
                    else:
                        message = f"The website returned an HTTP {status} response."
                        failure_type = "http_error"
                    raise FetchFailure(
                        message,
                        redirect_chain=redirect_chain,
                        final_url=current_url,
                        failure_type=failure_type,
                        status_code=status,
                    )

                content_type = response.headers.get("Content-Type", "").lower()
                if content_type and not any(
                    accepted in content_type
                    for accepted in ("text/html", "application/xhtml+xml")
                ):
                    raise FetchFailure(
                        "The website response was not an HTML page.",
                        redirect_chain=redirect_chain,
                        final_url=current_url,
                        failure_type="unsupported_type",
                        status_code=response.status_code,
                    )

                body = bytearray()
                is_truncated = False
                for chunk in response.iter_content(chunk_size=16_384):
                    if not chunk:
                        continue
                    body.extend(chunk)
                    if len(body) >= MAX_BODY_BYTES:
                        del body[MAX_BODY_BYTES:]
                        is_truncated = True
                        break

                if not body or not body.strip():
                    raise FetchFailure(
                        "The website returned an empty response.",
                        redirect_chain=redirect_chain,
                        final_url=current_url,
                        failure_type="empty_response",
                        status_code=response.status_code,
                    )

                # Reject binary magic bytes (e.g. PDF, PNG, GIF, ZIP, GZIP)
                prefix = bytes(body[:512]).lstrip()
                if prefix.startswith((b"%PDF", b"\x89PNG", b"GIF8", b"PK\x03\x04", b"\x1f\x8b")):
                    raise FetchFailure(
                        "The website response was not an HTML page.",
                        redirect_chain=redirect_chain,
                        final_url=current_url,
                        failure_type="unsupported_type",
                        status_code=response.status_code,
                    )

                html, encoding_used = decode_html_bytes(bytes(body), content_type)
                notice = (
                    "The website response exceeded the 2 MiB limit and was partially retrieved (truncated)."
                    if is_truncated
                    else None
                )
                return {
                    "html": html,
                    "final_url": current_url,
                    "redirect_chain": redirect_chain,
                    "notice": notice,
                    "is_truncated": is_truncated,
                    "status_code": response.status_code,
                    "content_type": content_type,
                    "encoding": encoding_used,
                    "fetch_status": "partial" if is_truncated else "success",
                }
            finally:
                response.close()

        raise FetchFailure(
            "The website redirected too many times.",
            redirect_chain=redirect_chain,
            final_url=redirect_chain[-1]["source"] if redirect_chain else None,
            failure_type="redirect_limit",
        )
    finally:
        session.close()
