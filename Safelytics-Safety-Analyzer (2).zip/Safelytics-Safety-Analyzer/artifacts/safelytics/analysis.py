"""Explainable, rule-based website safety and privacy analysis."""

from __future__ import annotations

import re
from difflib import SequenceMatcher
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

from bs4 import BeautifulSoup

try:
    from .security import normalize_url
except ImportError:  # Support direct execution during local development.
    from security import normalize_url

ADULT_KEYWORDS = [
    "porn", "pornography", "porno", "xxx", "x-rated", "sex", "sex video",
    "sexvideo", "sex tape", "sextape", "nude", "nudity", "naked", "nudes",
    "erotic", "erotica", "adult content", "adult film", "adult video", "nsfw",
    "explicit content", "explicit video", "hentai", "anime porn", "doujin",
    "onlyfans", "only fans", "cam girl", "camgirl", "webcam sex", "livesex",
    "live sex", "sexchat", "sex chat", "escort", "call girl", "massage parlour",
    "playboy", "penthouse", "hustler", "sexual", "sexually", "sexuality",
    "boobs", "breasts", "genitals", "vagina", "penis", "masturbation",
    "masturbate", "orgasm", "fetish", "kink", "bdsm", "bondage", "dominatrix",
    "dildo", "vibrator", "sex toy", "lingerie model", "milf", "gilf", "twink",
    "barely legal", "strip club", "lap dance", "topless",
]
VIOLENCE_KEYWORDS = [
    "kill", "blood", "weapon", "murder", "gore", "shooting", "stab", "brutal",
    "massacre", "death threat", "bomb", "assault rifle", "suicide", "self-harm",
    "terrorism", "execute",
]
HATE_SPEECH_KEYWORDS = [
    "hate", "hate speech", "racist", "racism", "sexist", "sexism", "homophobic",
    "antisemitic", "white supremacy", "neo-nazi", "slur", "discriminate",
    "bigot", "xenophobia", "islamophobia",
]
GAMBLING_KEYWORDS = [
    "casino", "gambling", "poker", "slot machine", "bet", "betting", "wager",
    "lottery", "jackpot", "blackjack", "roulette", "sportsbook", "odds",
    "bookie", "gamble", "winnings",
]
KEYWORD_CATEGORIES = {
    "Adult Content": ADULT_KEYWORDS,
    "Violence": VIOLENCE_KEYWORDS,
    "Hate Speech": HATE_SPEECH_KEYWORDS,
    "Gambling": GAMBLING_KEYWORDS,
}

KNOWN_TRACKERS = {
    "adform.net", "amazon-adsystem.com", "amplitude.com", "ads-twitter.com",
    "clarity.ms", "criteo.com", "doubleclick.net", "facebook.net",
    "google-analytics.com", "googletagmanager.com", "hotjar.com",
    "hubspot.com", "linkedin.com", "mixpanel.com", "optimizely.com",
    "segment.com", "tiktok.com", "quantserve.com", "scorecardresearch.com",
    "twitter.com", "connect.facebook.net",
}

BRANDS = {
    "adobe", "amazon", "apple", "bankofamerica", "facebook", "google",
    "instagram", "microsoft", "netflix", "paypal", "wellsfargo", "youtube",
}
BRAND_CONFUSABLES = str.maketrans({"0": "o", "1": "l", "3": "e", "5": "s"})

# These values are the only scoring policy knobs. Each dimension is reported
# separately; child-content findings never become phishing or malware findings.
SCORING_WEIGHTS = {
    "overall": {
        "child_content": 0.35,
        "phishing_scam": 0.30,
        "domain_redirect": 0.20,
        "privacy": 0.15,
    },
    "risk_level": {"low_max": 2.9, "warning_max": 6.4},
}

PHISHING_PHRASES = (
    "verify your account", "confirm your password", "account will be suspended",
    "urgent action required", "update your payment details", "claim your prize",
    "unusual sign-in activity", "your account expires today",
)
SENSITIVE_PATH_TERMS = {
    "account", "billing", "confirm", "login", "log-in", "payment", "password",
    "secure", "signin", "sign-in", "verify",
}
PRIVACY_LINK_TERMS = ("privacy", "data protection", "cookie policy")


def inspect_html_content(
    html: str | None,
    *,
    is_truncated: bool = False,
    fetch_notice: str | None = None,
) -> dict:
    """Extract visible HTML text and identify responses that cannot be inspected."""
    if not isinstance(html, str) or not html.strip():
        return {
            "available": False,
            "text": "",
            "notice": "The website returned an empty HTML response.",
            "title": "",
            "meta_description": "",
            "script_count": 0,
            "status": "empty",
            "uncompleted_checks": [
                "Child-content keyword scan (empty response)",
                "Page-level tracking and privacy signals (empty response)",
                "In-page forms and interactive elements (empty response)",
            ],
        }

    try:
        soup = BeautifulSoup(html, "lxml")
    except Exception:
        soup = BeautifulSoup(html, "html.parser")

    title = " ".join(soup.title.stripped_strings).strip() if soup.title else ""
    raw_text = " ".join(soup.stripped_strings).lower()
    raw_markup = html.lower()
    script_count = len(soup.find_all("script"))

    # Extract page metadata (meta description & keywords)
    meta_desc = ""
    desc_tag = soup.find("meta", attrs={"name": re.compile(r"^description$", re.I)})
    if not desc_tag:
        desc_tag = soup.find("meta", attrs={"property": re.compile(r"^og:description$", re.I)})
    if desc_tag and desc_tag.get("content"):
        meta_desc = desc_tag["content"].strip()

    meta_keywords = ""
    kw_tag = soup.find("meta", attrs={"name": re.compile(r"^keywords$", re.I)})
    if kw_tag and kw_tag.get("content"):
        meta_keywords = kw_tag["content"].strip()

    challenge_markers = (
        "verify you are human",
        "checking your browser",
        "complete the captcha",
        "complete the security check",
        "automated requests are not allowed",
        "enable javascript and cookies to continue",
        "request blocked",
        "cf-chl-",
        "cloudflare ray id",
        "turnstile",
        "attention required! | cloudflare",
        "ddos protection by cloudflare",
    )
    blocked = any(marker in raw_markup or marker in raw_text for marker in challenge_markers)
    blocked = blocked or title.lower() in {"access denied", "403 forbidden", "just a moment..."}
    if blocked:
        return {
            "available": False,
            "text": raw_text,
            "notice": (
                "The website returned an access-denied or human-verification page. "
                "Safelytics will not bypass it."
            ),
            "title": title,
            "meta_description": meta_desc,
            "script_count": script_count,
            "status": "challenge",
            "uncompleted_checks": [
                "Child-content suitability keywords (access blocked by challenge)",
                "Page tracking and privacy signals (access blocked by challenge)",
                "In-page forms and interactive elements (access blocked by challenge)",
            ],
        }

    # Inspect noscript and SPA indicators before decomposing
    noscript_tags = soup.find_all("noscript")
    noscript_text = " ".join(ns.get_text(separator=" ", strip=True).lower() for ns in noscript_tags)
    has_spa_mount = bool(
        soup.find(id=re.compile(r"^(root|app|__next|main-app|app-root)$", re.I))
        or soup.find(attrs={"data-reactroot": True})
    )
    js_requirement_phrases = (
        "enable javascript",
        "you need to enable javascript",
        "javascript is required",
        "please enable javascript",
        "javascript must be enabled",
        "turn on javascript",
        "requires javascript",
        "browser does not support javascript",
    )

    # Decompose script, style, and media noise
    for tag in soup(
        ["script", "style", "noscript", "template", "svg", "canvas", "iframe", "video", "audio"]
    ):
        tag.decompose()

    # Decompose navigation and footer clutter
    for tag in soup(["nav", "footer", "aside"]):
        tag.decompose()

    # Safely decompose hidden elements
    hidden_tags = []
    for tag in soup.find_all(True):
        style = re.sub(r"\s+", "", tag.get("style", "").lower())
        aria_hidden = tag.get("aria-hidden", "").strip().lower() == "true"
        is_hidden = (
            tag.has_attr("hidden")
            or "display:none" in style
            or "visibility:hidden" in style
            or (aria_hidden and tag.name not in {"html", "body", "main", "article"})
        )
        if is_hidden:
            hidden_tags.append(tag)
    for tag in hidden_tags:
        try:
            tag.decompose()
        except Exception:
            pass

    text = re.sub(r"\s+", " ", " ".join(soup.stripped_strings)).strip()
    lowered_text = text.lower()

    # Check for JavaScript dependency
    is_js_dependent = (
        (script_count > 0 and len(text) < 120)
        or (has_spa_mount and len(text) < 200)
        or (any(phrase in lowered_text for phrase in js_requirement_phrases) and len(text) < 250)
        or any(phrase in noscript_text for phrase in js_requirement_phrases)
    )

    if is_js_dependent and len(text) < 250:
        return {
            "available": False,
            "text": lowered_text,
            "notice": (
                "The page returned too little visible text and appears to rely on "
                "client-side JavaScript, which Safelytics does not run."
            ),
            "title": title,
            "meta_description": meta_desc,
            "script_count": script_count,
            "status": "javascript_required",
            "uncompleted_checks": [
                "Child-content keyword scan (client-side JavaScript rendering required)",
                "Page tracking and privacy signals (client-side JavaScript rendering required)",
                "In-page forms and interactive elements (client-side JavaScript rendering required)",
            ],
        }

    if len(text) < 40:
        return {
            "available": False,
            "text": lowered_text,
            "notice": (
                "The page returned too little readable text to evaluate its content "
                "and privacy indicators."
            ),
            "title": title,
            "meta_description": meta_desc,
            "script_count": script_count,
            "status": "empty",
            "uncompleted_checks": [
                "Child-content keyword scan (insufficient readable text)",
                "Page privacy indicators (insufficient readable text)",
            ],
        }

    status = "partial" if is_truncated else "success"
    notice = fetch_notice or (
        "The page exceeded the 2 MiB limit and was partially retrieved (truncated). "
        "Analysis was performed on the first 2 MiB."
        if is_truncated
        else None
    )

    return {
        "available": True,
        "text": lowered_text,
        "notice": notice,
        "title": title,
        "meta_description": meta_desc,
        "meta_keywords": meta_keywords,
        "script_count": script_count,
        "status": status,
        "uncompleted_checks": (
            ["Remaining content beyond 2 MiB was not analyzed (truncated)."]
            if is_truncated
            else []
        ),
    }


def extract_text(html: str) -> str:
    """Extract visible text from common HTML structures."""
    return inspect_html_content(html)["text"]


def count_keyword_hits(text: str, keywords: list[str]) -> int:
    return sum(
        len(re.findall(r"\b" + re.escape(keyword) + r"\b", text, flags=re.IGNORECASE))
        for keyword in keywords
    )


def _score_color(score: float) -> str:
    if score < 2.5:
        return "green"
    if score < 6.5:
        return "orange"
    return "red"


def classify_content(text: str, available: bool = True) -> dict:
    """Classify child-content terms without treating them as cyber threats."""
    counts = {
        category: count_keyword_hits(text, terms)
        for category, terms in KEYWORD_CATEGORIES.items()
    }
    total_hits = sum(counts.values())
    detected = [category for category, count in counts.items() if count]
    risk_score = round(min(total_hits / 15 * 10, 10), 1)
    if counts["Adult Content"]:
        risk_score = 10.0
    if not available:
        level, color, risk_score = "Not Available", "grey", None
    elif not total_hits:
        level, color = "Safe", "green"
    elif total_hits <= 3:
        level, color = "Warning", "orange"
    else:
        level, color = "Unsafe", "red"

    return {
        "available": available,
        "categories": {
            name: {"count": count, "detected": count > 0}
            for name, count in counts.items()
        },
        "detected_categories": detected,
        "adult_count": counts["Adult Content"],
        "violence_count": counts["Violence"],
        "hate_count": counts["Hate Speech"],
        "gambling_count": counts["Gambling"],
        "total_hits": total_hits,
        "risk_score": risk_score,
        "level": level,
        "color": color,
    }


def _registrable_domain(hostname: str) -> str:
    try:
        import ipaddress

        ipaddress.ip_address(hostname)
        return hostname
    except ValueError:
        pass
    labels = hostname.lower().rstrip(".").split(".")
    if len(labels) <= 2:
        return ".".join(labels)
    common_second_level_suffixes = {
        "ac.uk", "co.in", "co.jp", "co.nz", "co.uk", "com.au", "com.br",
        "com.cn", "com.mx", "com.sg", "com.tr", "gov.uk", "org.uk",
    }
    last_two = ".".join(labels[-2:])
    return ".".join(labels[-3:]) if last_two in common_second_level_suffixes else last_two


def _add_finding(
    findings: list[dict],
    finding_id: str,
    category: str,
    title: str,
    explanation: str,
    weight: float,
    evidence: str,
    severity: str = "warning",
) -> None:
    """Append a stable, de-duplicated rule result."""
    if any(item["id"] == finding_id for item in findings):
        return
    findings.append(
        {
            "id": finding_id,
            "category": category,
            "title": title,
            "explanation": explanation,
            "weight": round(weight, 2),
            "evidence": evidence,
            "severity": severity,
        }
    )


def score_findings(findings: list[dict]) -> float:
    """Sum each unique rule once and cap the component at ten."""
    unique = {}
    for item in findings:
        unique.setdefault(item["id"], item)
    return round(min(10.0, sum(item["weight"] for item in unique.values())), 1)


def analyze_phishing(url: str, html: str | None) -> dict:
    """Detect explainable scam indicators in the URL and submitted HTML."""
    normalized = normalize_url(url)
    parsed = urlsplit(normalized)
    hostname = parsed.hostname or ""
    root_domain = _registrable_domain(hostname)
    root_label = root_domain.split(".")[0]
    findings: list[dict] = []
    try:
        import ipaddress

        ipaddress.ip_address(hostname)
        is_ip_address = True
    except ValueError:
        is_ip_address = False

    if is_ip_address:
        _add_finding(
            findings, "url.ip_host", "phishing_scam", "IP-address website",
            "An IP address is used instead of a recognizable website name. This can be legitimate, but is unusual for a public sign-in or payment page.",
            2.0, hostname,
        )

    if "xn--" in hostname:
        _add_finding(
            findings, "url.punycode", "phishing_scam", "Internationalized hostname",
            "The address contains an encoded internationalized domain name. Similar-looking characters can make an address harder to recognize.",
            1.0, hostname,
        )

    subdomain_count = max(0, len(hostname.split(".")) - len(root_domain.split(".")))
    if subdomain_count > 2:
        _add_finding(
            findings, "url.deep_subdomains", "phishing_scam", "Many subdomains",
            "Several subdomains can hide which organization controls the actual domain. Read the address from right to left before trusting it.",
            1.4, f"{subdomain_count} subdomains",
        )

    confusable_root = root_label.translate(BRAND_CONFUSABLES)
    similar_brand = next(
        (
            brand for brand in sorted(BRANDS)
            if root_label != brand
            and SequenceMatcher(None, confusable_root, brand).ratio() >= 0.78
        ),
        None,
    )
    brand_token = next(
        (
            brand for brand in sorted(BRANDS)
            if brand in root_label.split("-") and root_label != brand
        ),
        None,
    )
    impersonated = similar_brand or brand_token
    if impersonated:
        _add_finding(
            findings, "url.brand_impersonation", "phishing_scam", "Brand-like domain spelling",
            "The registered domain resembles a well-known brand but is not that brand's usual domain. Confirm the exact domain independently.",
            3.5, f"Domain: {root_domain}; resembles: {impersonated}",
            severity="high",
        )

    path_terms = {
        segment.lower()
        for segment in re.split(r"[/_.\-=]+", parsed.path + " " + parsed.query)
        if segment
    }
    sensitive_terms = sorted(path_terms & SENSITIVE_PATH_TERMS)
    if len(sensitive_terms) >= 2:
        _add_finding(
            findings, "url.sensitive_route", "phishing_scam", "Sensitive sign-in or payment route",
            "The address combines multiple sign-in, account, verification, or payment terms. Check the domain carefully before entering information.",
            0.8, ", ".join(sensitive_terms),
        )

    if html:
        soup = BeautifulSoup(html, "html.parser")
        page_text = " ".join(soup.stripped_strings).lower()
        matched_phrases = [
            phrase for phrase in PHISHING_PHRASES
            if re.search(r"\b" + re.escape(phrase) + r"\b", page_text)
        ]
        if matched_phrases:
            _add_finding(
                findings, "text.urgent_account_language", "phishing_scam", "Urgent account language",
                "The page uses common pressure tactics that can be used to push people into sharing account or payment details. The text alone does not prove fraud.",
                2.2, matched_phrases[0],
            )

        password_forms = []
        payment_forms = []
        external_password_forms = []
        for form in soup.find_all("form"):
            fields = form.find_all(["input", "textarea", "select"])
            input_types = {
                (field.get("type") or "").lower()
                for field in fields
            }
            field_names = " ".join(
                f"{field.get('name', '')} {field.get('id', '')} {field.get('autocomplete', '')}"
                for field in fields
            ).lower()
            has_password = "password" in input_types or "current-password" in field_names
            has_payment = bool(input_types & {"credit-card", "cc-number"}) or bool(
                re.search(r"\b(card number|credit card|cvv|security code)\b", field_names)
            )
            if has_password:
                password_forms.append(form)
            if has_payment:
                payment_forms.append(form)
            action = form.get("action", "")
            if action:
                action_host = (urlsplit(urljoin(normalized, action)).hostname or "").lower()
                if has_password and action_host and action_host != hostname.lower():
                    external_password_forms.append(action_host)

        if password_forms or payment_forms:
            form_kinds = []
            if password_forms:
                form_kinds.append("password")
            if payment_forms:
                form_kinds.append("payment")
            _add_finding(
                findings, "html.sensitive_form", "phishing_scam", "Sensitive information form",
                "The page contains a form asking for sign-in or payment information. That can be normal on a trusted service, so verify the domain before submitting.",
                1.4 if not external_password_forms else 3.6,
                f"{', '.join(form_kinds)} form detected",
                severity="high" if external_password_forms else "warning",
            )

        if external_password_forms:
            _add_finding(
                findings, "html.external_password_form", "phishing_scam", "Password sent to another domain",
                "A password form submits to a different website domain. Confirm that this destination is expected before entering credentials.",
                3.0, ", ".join(sorted(set(external_password_forms))),
                severity="high",
            )

    return {
        "findings": findings,
        "risk_score": score_findings(findings),
        "available": html is not None,
    }


def analyze_domain(url: str, redirect_chain: list[dict] | None = None, final_url: str | None = None) -> dict:
    """Summarize URL components and inspect redirect destinations."""
    normalized = normalize_url(url)
    parsed = urlsplit(normalized)
    hostname = parsed.hostname or ""
    domain = _registrable_domain(hostname)
    redirects = None
    if redirect_chain is not None:
        redirects = []
        for hop in redirect_chain:
            destination = hop.get("destination", "")
            redirects.append(
                {
                    **hop,
                    "source": sanitize_url_for_storage(hop.get("source", normalized)),
                    "destination": (
                        sanitize_url_for_storage(destination)
                        if destination.startswith(("http://", "https://"))
                        else destination
                    ),
                }
            )
    final = sanitize_url_for_storage(final_url) if final_url else None
    final_parsed = urlsplit(final) if final else None
    final_domain = (
        _registrable_domain(final_parsed.hostname or "") if final_parsed else None
    )
    findings: list[dict] = []

    if hostname != domain:
        subdomain_count = max(0, len(hostname.split(".")) - len(domain.split(".")))
        if subdomain_count > 2:
            _add_finding(
                findings, "domain.excessive_subdomains", "domain_redirect", "Unusually deep domain",
                "The URL has several subdomains. The registered domain is the part that identifies the site owner.",
                1.0, hostname,
            )

    if redirects is not None and len(redirects) > 3:
        _add_finding(
            findings, "redirect.long_chain", "domain_redirect", "Long redirect chain",
            "The website passes through several redirects before reaching the page. This makes the final destination harder to predict.",
            1.2, f"{len(redirects)} redirects",
        )
    if final_domain and domain != final_domain:
        _add_finding(
            findings, "redirect.domain_change", "domain_redirect", "Redirect to a different registered domain",
            "The final page is hosted on a different registered domain from the submitted address. This can be expected, but check that the destination is intentional.",
            1.5, f"{domain} → {final_domain}",
        )
    if final_parsed and parsed.scheme == "https" and final_parsed.scheme == "http":
        _add_finding(
            findings, "redirect.https_downgrade", "domain_redirect", "Redirect to an unencrypted connection",
            "The scan began with HTTPS but ended at HTTP, so the final connection does not use transport encryption.",
            3.0, final,
            severity="high",
        )
    if redirects and any(hop.get("blocked") for hop in redirects):
        _add_finding(
            findings,
            "redirect.blocked_target",
            "domain_redirect",
            "Redirect destination was not followed",
            "A redirect pointed to a non-public, disallowed, or unverifiable destination. Safelytics stopped before visiting it.",
            3.0,
            "The next destination was blocked by the safe-fetch checks.",
            severity="high",
        )

    return {
        "hostname": hostname,
        "registered_domain": domain,
        "scheme": parsed.scheme,
        "path": parsed.path or "/",
        "final_url": final,
        "final_url_available": final is not None,
        "final_domain": final_domain,
        "redirect_chain": redirects,
        "redirect_analysis_available": redirects is not None,
        "redirect_count": len(redirects) if redirects is not None else None,
        "registration_age": None,
        "registration_age_label": "Unavailable — not inferred",
        "findings": findings,
        "risk_score": score_findings(findings),
    }


def analyze_privacy(url: str, html: str | None, page_url: str | None = None) -> dict:
    """Report privacy signals visible in URL and static page markup."""
    normalized = normalize_url(url)
    effective_url = normalize_url(page_url) if page_url else normalized
    parsed = urlsplit(effective_url)
    page_host = (parsed.hostname or "").lower()
    page_domain = _registrable_domain(page_host) if page_host else ""
    is_https = parsed.scheme == "https"
    findings: list[dict] = []

    if not is_https:
        _add_finding(
            findings, "privacy.http", "privacy", "Connection does not use HTTPS",
            "The page uses HTTP, which does not encrypt information sent between the browser and website.",
            2.0, "HTTP connection",
            severity="high",
        )

    if html is None:
        return {
            "available": False,
            "connection": "Secure (HTTPS)" if is_https else "Not Secure (HTTP)",
            "is_https": is_https,
            "tracker_count": None,
            "tracker_domains": [],
            "script_count": None,
            "script_risk": "Not available",
            "third_party_resource_count": None,
            "third_party_resources": [],
            "external_form_destinations": [],
            "cookie_indicators": [],
            "privacy_policy_links": [],
            "privacy_score": score_findings(findings) if not is_https else None,
            "findings": findings,
            "level": "Not Available",
            "color": "grey",
        }

    soup = BeautifulSoup(html, "html.parser")
    tracker_domains = set()
    third_party_hosts = set()
    tracker_hosts = set()
    privacy_links = set()
    external_forms = set()
    cookie_indicators = set()

    def add_resource(raw: str | None) -> None:
        if not raw:
            return
        resource_host = (urlsplit(urljoin(effective_url, raw)).hostname or "").lower()
        if not resource_host or _registrable_domain(resource_host) == page_domain:
            return
        third_party_hosts.add(resource_host)
        for tracker in KNOWN_TRACKERS:
            if resource_host == tracker or resource_host.endswith("." + tracker):
                tracker_domains.add(tracker)
                tracker_hosts.add(resource_host)

    for tag in soup.find_all(["script", "link", "img", "iframe", "source", "video", "audio"]):
        add_resource(tag.get("src") or tag.get("href"))

    for anchor in soup.find_all("a", href=True):
        link_text = " ".join(anchor.stripped_strings).lower()
        link_target = urljoin(effective_url, anchor["href"])
        if any(term in link_text or term in anchor["href"].lower() for term in PRIVACY_LINK_TERMS):
            privacy_links.add(link_target)

    for form in soup.find_all("form"):
        action = form.get("action", "")
        destination = urljoin(effective_url, action) if action else effective_url
        destination_host = (urlsplit(destination).hostname or "").lower()
        if destination_host and destination_host != page_host:
            external_forms.add(destination_host)

    markup = str(soup).lower()
    if "document.cookie" in markup or "cookieStore" in markup:
        cookie_indicators.add("Page scripts reference browser cookie storage")
    if re.search(r"\b(cookie|consent|tracking preferences)\b", markup):
        cookie_indicators.add("Cookie or consent wording appears in the page markup")

    if tracker_domains:
        _add_finding(
            findings, "privacy.known_trackers", "privacy", "Known tracker references",
            "The page markup references domains associated with analytics or advertising. A reference does not prove what data was collected.",
            min(3.0, 1.0 + 0.5 * (len(tracker_domains) - 1)),
            ", ".join(sorted(tracker_domains)),
        )
    if third_party_hosts:
        non_tracker_hosts = third_party_hosts - tracker_hosts
        if non_tracker_hosts:
            _add_finding(
                findings, "privacy.third_party_resources", "privacy", "Third-party resources",
                "The page loads at least one resource from another domain. This may reveal a visit to that resource provider, but static HTML cannot establish what is collected.",
                0.8, ", ".join(sorted(non_tracker_hosts)[:5]),
            )
    if external_forms:
        _add_finding(
            findings, "privacy.external_forms", "privacy", "Form sends data to another domain",
            "At least one form submits to a different domain. Check that this destination is expected before submitting personal information.",
            1.5, ", ".join(sorted(external_forms)),
        )
    if cookie_indicators:
        _add_finding(
            findings, "privacy.cookie_indicators", "privacy", "Cookie-related indicators",
            "The markup mentions cookies or references browser cookie storage. This does not reveal the complete cookie behavior or retention period.",
            0.8, "; ".join(sorted(cookie_indicators)),
        )
    if not privacy_links:
        _add_finding(
            findings, "privacy.policy_not_found", "privacy", "No privacy-policy link detected",
            "A privacy-policy link was not found in the scanned markup. It may exist on another page or be added dynamically.",
            0.4, "No matching link in static HTML",
        )
    script_count = len(soup.find_all("script"))
    if script_count >= 5:
        script_weight = 0.6 if script_count <= 10 else 1.0
        _add_finding(
            findings, "privacy.script_count", "privacy", "Multiple script tags",
            "The page contains multiple script tags. A script count alone does not establish tracking or harmful behavior.",
            script_weight, f"{script_count} script tags",
        )

    tracker_count = len(tracker_domains)
    script_risk = "Low" if script_count < 5 else ("Medium" if script_count <= 10 else "High")
    privacy_score = score_findings(findings)
    if privacy_score < 2.5:
        level, color = "Low", "green"
    elif privacy_score < 6.5:
        level, color = "Medium", "orange"
    else:
        level, color = "High", "red"

    return {
        "available": True,
        "connection": "Secure (HTTPS)" if is_https else "Not Secure (HTTP)",
        "is_https": is_https,
        "tracker_count": tracker_count,
        "tracker_domains": sorted(tracker_domains),
        "script_count": script_count,
        "script_risk": script_risk,
        "third_party_resource_count": len(third_party_hosts),
        "third_party_resources": sorted(third_party_hosts),
        "external_form_destinations": sorted(external_forms),
        "cookie_indicators": sorted(cookie_indicators),
        "privacy_policy_links": sorted(privacy_links),
        "privacy_score": privacy_score,
        "findings": findings,
        "level": level,
        "color": color,
    }


def calculate_risk(content: dict, phishing: dict, domain: dict, privacy: dict) -> dict:
    """Calculate a configurable, weighted summary with incomplete dimensions excluded."""
    components = {
        "child_content": content.get("risk_score"),
        "phishing_scam": phishing.get("risk_score"),
        "domain_redirect": domain.get("risk_score"),
        "privacy": privacy.get("privacy_score"),
    }
    weights = SCORING_WEIGHTS["overall"]
    available = {
        name: score for name, score in components.items()
        if score is not None
    }
    weight_total = sum(weights[name] for name in available)
    breakdown = []
    total = 0.0
    for name, score in components.items():
        if score is None:
            breakdown.append(
                {"component": name, "score": None, "weight": None, "contribution": None}
            )
            continue
        adjusted_weight = weights[name] / weight_total if weight_total else 0
        contribution = score * adjusted_weight
        total += contribution
        breakdown.append(
            {
                "component": name,
                "score": round(score, 1),
                "weight": round(adjusted_weight, 3),
                "contribution": round(contribution, 2),
            }
        )
    overall_score = round(min(10.0, total), 1)
    limits = SCORING_WEIGHTS["risk_level"]
    if overall_score <= limits["low_max"]:
        level, color = "Low Risk", "green"
    elif overall_score <= limits["warning_max"]:
        level, color = "Warning", "orange"
    else:
        level, color = "High Risk", "red"
    return {
        "risk_score": overall_score,
        "risk_level": level,
        "risk_color": color,
        "component_scores": components,
        "score_breakdown": breakdown,
        "scoring_weights": weights,
    }


def build_findings(content: dict, phishing: dict, domain: dict, privacy: dict) -> list[dict]:
    """Combine separate child-content and cybersecurity reports."""
    findings = []
    for name, info in content.get("categories", {}).items():
        if info["detected"]:
            findings.append(
                {
                    "id": f"content.{name.lower().replace(' ', '_')}",
                    "category": "child_content",
                    "title": f"{name} wording detected",
                    "explanation": "A keyword match appeared in the scanned text. Context matters; a match is not a conclusion about the page.",
                    "weight": None,
                    "evidence": f"{info['count']} keyword match(es)",
                    "severity": "warning",
                }
            )
    for report in (phishing, domain, privacy):
        findings.extend(report.get("findings", []))
    return findings


def annotate_finding_contributions(findings: list[dict], score_breakdown: list[dict]) -> list[dict]:
    """Attach each rule's incremental component and weighted-summary contribution."""
    component_for_category = {
        "phishing_scam": "phishing_scam",
        "domain_redirect": "domain_redirect",
        "privacy": "privacy",
    }
    overall_weights = {
        row["component"]: row.get("weight")
        for row in score_breakdown
    }
    allocated = {name: 0.0 for name in component_for_category.values()}

    for finding in findings:
        component = component_for_category.get(finding.get("category"))
        weight = finding.get("weight")
        if component is None or weight is None:
            finding["score_contribution"] = None
            finding["overall_contribution"] = None
            finding["score_note"] = (
                "Counts toward child-content suitability only; it is not a cybersecurity finding."
                if finding.get("category") == "child_content"
                else "No separate score contribution is available."
            )
            continue

        contribution = min(float(weight), max(0.0, 10.0 - allocated[component]))
        allocated[component] += contribution
        overall_weight = overall_weights.get(component)
        finding["score_contribution"] = round(contribution, 2)
        finding["overall_contribution"] = (
            round(contribution * overall_weight, 2)
            if overall_weight is not None
            else None
        )
        finding["score_note"] = (
            f"+{finding['score_contribution']} points in the {component.replace('_', ' ')} "
            "component before the overall weighting."
        )

    return findings


def compare_scans(first: dict, second: dict) -> dict:
    """Compare compatible scans and return stable, explainable change rows."""
    if not isinstance(first, dict) or not isinstance(second, dict):
        raise ValueError("Both saved scans must be valid records.")

    def normalized_address(scan: dict) -> str | None:
        raw_address = scan.get("normalized_url") or scan.get("url")
        if not isinstance(raw_address, str) or not raw_address.strip():
            return None
        try:
            return sanitize_url_for_storage(raw_address)
        except (TypeError, ValueError):
            return None

    first_address = normalized_address(first)
    second_address = normalized_address(second)
    if not first_address or not second_address:
        raise ValueError("A saved scan is missing a valid website address.")
    if first_address != second_address:
        raise ValueError("Only scans of the same normalized website can be compared.")
    if (str(first.get("scanned_at", "")), str(first.get("id", ""))) <= (
        str(second.get("scanned_at", "")),
        str(second.get("id", "")),
    ):
        earlier, later = first, second
    else:
        earlier, later = second, first

    def add_change(label: str, before, after) -> dict:
        comparable = before is not None and after is not None
        return {
            "label": label,
            "before": before,
            "after": after,
            "comparable": comparable,
            "changed": comparable and before != after,
        }

    changes = [
        add_change("Overall risk score", earlier.get("risk_score"), later.get("risk_score")),
        add_change(
            "Overall risk category", earlier.get("risk_level"), later.get("risk_level")
        ),
    ]
    changes.append(
        add_change(
            "Scan completeness",
            "Partial" if earlier.get("is_partial") is True else (
                "Complete" if earlier.get("is_partial") is False else None
            ),
            "Partial" if later.get("is_partial") is True else (
                "Complete" if later.get("is_partial") is False else None
            ),
        )
    )
    old_components = earlier.get("component_scores")
    new_components = later.get("component_scores")
    old_components = old_components if isinstance(old_components, dict) else {}
    new_components = new_components if isinstance(new_components, dict) else {}
    for component in ("child_content", "phishing_scam", "domain_redirect", "privacy"):
        changes.append(
            add_change(
                f"{component.replace('_', ' ').title()} score",
                old_components.get(component),
                new_components.get(component),
            )
        )

    old_content = earlier.get("content", {})
    new_content = later.get("content", {})
    def content_category_counts(report) -> list[str] | None:
        if not isinstance(report, dict) or report.get("available") is False:
            return None
        categories = report.get("categories")
        if not isinstance(categories, dict) or any(
            name not in categories
            or not isinstance(categories[name], dict)
            or "count" not in categories[name]
            for name in KEYWORD_CATEGORIES
        ):
            return None
        return [
            f"{name}: {categories[name]['count']}"
            for name in KEYWORD_CATEGORIES
        ]

    old_categories = content_category_counts(old_content)
    new_categories = content_category_counts(new_content)
    changes.append(add_change("Content category counts", old_categories, new_categories))

    old_domain = earlier.get("domain", {})
    new_domain = later.get("domain", {})
    old_domain = old_domain if isinstance(old_domain, dict) else {}
    new_domain = new_domain if isinstance(new_domain, dict) else {}

    def redirect_destinations(domain_report: dict) -> list[str] | None:
        if domain_report.get("redirect_analysis_available") is False:
            return None
        chain = domain_report.get("redirect_chain")
        if not isinstance(chain, list):
            return None
        return [
            str(item["destination"])
            for item in chain
            if isinstance(item, dict) and item.get("destination") is not None
        ]

    def finding_evidence(section) -> list[str] | None:
        if not isinstance(section, dict) or section.get("available") is False:
            return None
        findings = section.get("findings")
        if not isinstance(findings, list):
            return None
        snapshots = []
        for finding in findings:
            if not isinstance(finding, dict):
                continue
            title = str(finding.get("title") or finding.get("id") or "Finding")
            evidence = str(finding.get("evidence") or "").strip()
            snapshots.append(f"{title}: {evidence}" if evidence else title)
        return sorted(set(snapshots))

    for label, key in (
        ("Phishing findings", "phishing"),
        ("Domain findings", "domain"),
        ("Privacy findings", "privacy"),
    ):
        changes.append(
            add_change(
                label,
                finding_evidence(earlier.get(key)),
                finding_evidence(later.get(key)),
            )
        )

    changes.append(
        add_change(
            "Final destination",
            old_domain.get("final_url")
            if old_domain.get("final_url_available", old_domain.get("final_url") is not None)
            else None,
            new_domain.get("final_url")
            if new_domain.get("final_url_available", new_domain.get("final_url") is not None)
            else None,
        )
    )
    changes.append(
        add_change(
            "Redirect destinations",
            redirect_destinations(old_domain),
            redirect_destinations(new_domain),
        )
    )

    old_privacy = earlier.get("privacy", {})
    new_privacy = later.get("privacy", {})
    old_privacy = old_privacy if isinstance(old_privacy, dict) else {}
    new_privacy = new_privacy if isinstance(new_privacy, dict) else {}

    def privacy_values(report: dict, field: str) -> list[str] | None:
        if report.get("available") is False:
            return None
        values = report.get(field)
        if not isinstance(values, list):
            return None
        return sorted(str(value) for value in values)

    for label, key in (
        ("Known tracker domains", "tracker_domains"),
        ("Third-party resources", "third_party_resources"),
        ("External form destinations", "external_form_destinations"),
        ("Cookie indicators", "cookie_indicators"),
        ("Privacy-policy links", "privacy_policy_links"),
    ):
        changes.append(
            add_change(
                label,
                privacy_values(old_privacy, key),
                privacy_values(new_privacy, key),
            )
        )

    return {
        "earlier": earlier,
        "later": later,
        "changes": changes,
        "changed_count": sum(change["changed"] for change in changes),
        "notice": (
            "A change between scans does not by itself prove that a website has become "
            "malicious or unsafe. Pages can change for ordinary reasons."
        ),
    }


def sanitize_url_for_storage(url: str) -> str:
    """Remove common secrets from query strings before persisting scan history."""
    parsed = urlsplit(normalize_url(url))
    sensitive_names = {
        "access_key", "access_token", "api_key", "apikey", "auth", "authorization",
        "client_secret", "code", "credential", "csrf", "id_token", "key",
        "password", "passwd", "refresh_token", "secret", "session", "session_id",
        "sessionid", "sig", "signature", "token",
    }
    query = urlencode(
        [
            (
                key,
                "[redacted]"
                if key.lower() in sensitive_names
                or any(
                    marker in key.lower()
                    for marker in (
                        "access_token", "api_key", "apikey", "client_secret",
                        "credential", "password", "passwd", "refresh_token",
                        "session_id", "signature", "token",
                    )
                )
                else value,
            )
            for key, value in parse_qsl(parsed.query, keep_blank_values=True)
        ],
        doseq=True,
    )
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, query, ""))
