---
name: Python toolchain setup
description: Python runtime and package-install behavior observed in this project environment.
---

The workspace's system Python was 3.13 but had no `pip`; installing Python packages through the managed package callback failed because the interpreter is externally managed. The available module list included `python-base-3.13`, but `python-3.13` was not an installable module ID.

**Why:** repeated package-install attempts do not resolve the environment mismatch and can alter `.replit` even when installation fails.

**How to apply:** check the exact available module IDs and verify the package runner before depending on Python tests or starting the Flask app. Restore unintended `.replit` changes through Replit's configuration validation tool.
